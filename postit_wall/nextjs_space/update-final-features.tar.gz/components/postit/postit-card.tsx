'use client'

import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { ExternalLink, Trash2, Heart, Eye, MessageSquare, Send, Flag, Play, Share2, Sun, Moon, Cloud, CloudFog, CloudRain, CloudSnow, CloudLightning } from 'lucide-react'
import { CustomLinkPreview } from './link-preview'
import { PostitShareButton } from './postit-share-button'
import { UserFollowButton } from './user-follow-button'

const getConditionStr = (code: number) => {
  if (code === 0 || code === 1) return 'sunny';
  if (code === 2 || code === 3) return 'cloudy';
  if (code >= 51 && code <= 67) return 'rainy';
  if (code >= 71 && code <= 77) return 'snowy';
  if (code >= 80 && code <= 82) return 'rainy';
  if (code >= 85 && code <= 86) return 'snowy';
  if (code >= 95 && code <= 99) return 'storm';
  if (code === 45 || code === 48) return 'foggy';
  return 'cloudy';
}

const getConditionDescTR = (code: number) => {
  if (code === 0) return 'Açık ve sıcak.';
  if (code === 1) return 'Güneşli hava etkili olacak.';
  if (code === 2) return 'Az bulutlu ve sıcak.';
  if (code === 3) return 'Parçalı bulutlu bir gün.';
  if (code >= 51 && code <= 67) return 'Öğleden sonra yer yer kısa süreli sağanak geçişleri bekleniyor.';
  if (code >= 71 && code <= 77) return 'Kar yağışlı bir gün.';
  if (code >= 80 && code <= 82) return 'Sağanak yağış bekleniyor.';
  if (code >= 85 && code <= 86) return 'Yoğun kar yağışlı.';
  if (code >= 95 && code <= 99) return 'Gök gürültülü sağanak geçişleri bekleniyor.';
  if (code === 45 || code === 48) return 'Yer yer yoğun sisli.';
  return 'Genellikle bulutlu.';
}

const getSuffix = (word: string) => {
  if (!word) return 'de';
  const match = word.toLocaleLowerCase('tr-TR').match(/[aıoueiöü]/g);
  const lastVowel = match ? match[match.length - 1] : 'e';
  const lastChar = word.toLocaleLowerCase('tr-TR').slice(-1);
  const isHardConsonant = ['f','s','t','k','ç','ş','h','p'].includes(lastChar);
  const isFront = ['e','i','ö','ü'].includes(lastVowel);
  if (isFront) return isHardConsonant ? 'te' : 'de';
  return isHardConsonant ? 'ta' : 'da';
};

const getWeatherUI = (weatherBg: string, iconSet: string = 'default', appearance: any = {}) => {
  if (!weatherBg) return { bg: '', icon: null, text: 'text-white', bgImage: null };
  const parts = weatherBg.split('_');
  const condition = parts[0];
  const isNight = parts.length > 1 && parts[1] === 'night';
  
  let bgColClass = "bg-slate-800";
  
  if (condition === 'sunny') {
    if (isNight) bgColClass = "bg-slate-900";
    else bgColClass = "bg-sky-500";
  } else if (condition === 'cloudy') {
    if (isNight) bgColClass = "bg-slate-800";
    else bgColClass = "bg-slate-600";
  } else if (condition === 'rainy' || condition === 'storm') {
    bgColClass = "bg-slate-700";
  } else if (condition === 'snowy' || condition === 'foggy') {
    bgColClass = "bg-slate-400";
  }
  
  const bg = `${bgColClass}`;

  const renderIcon = (defaultIcon: any, emoji: string) => {
    if (iconSet === 'emoji') {
       return <span className="text-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] leading-none drop-shadow-md flex items-center justify-center">{emoji}</span>;
    } else if (iconSet === 'animated') {
       return <span className="text-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] leading-none drop-shadow-[0_0_20px_rgba(255,255,255,0.8)] animate-pulse flex items-center justify-center">{emoji}</span>;
    }
    return defaultIcon;
  };

  let bgImage = null;
  if (condition === 'sunny' && appearance?.weatherBgSunny) bgImage = appearance.weatherBgSunny;
  else if (condition === 'cloudy' && appearance?.weatherBgCloudy) bgImage = appearance.weatherBgCloudy;
  else if (condition === 'rainy' && appearance?.weatherBgRainy) bgImage = appearance.weatherBgRainy;
  else if (condition === 'snowy' && appearance?.weatherBgSnowy) bgImage = appearance.weatherBgSnowy;
  else if (condition === 'foggy' && appearance?.weatherBgFoggy) bgImage = appearance.weatherBgFoggy;
  else if ((condition === 'storm' || condition === 'stormy') && appearance?.weatherBgStormy) bgImage = appearance.weatherBgStormy;

  if (condition === 'sunny') {
    if (isNight) return { bg, text: 'text-indigo-100 drop-shadow-xl', bgImage, icon: renderIcon(<Moon className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-blue-100 drop-shadow-[0_0_25px_rgba(255,255,255,0.7)]" fill="currentColor" />, '🌙') };
    return { bg, text: 'text-white drop-shadow-xl', bgImage, icon: renderIcon(<Sun className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-yellow-300 drop-shadow-[0_0_35px_rgba(253,224,71,1)]" fill="currentColor" />, '☀️') };
  }
  if (condition === 'cloudy') {
    if (isNight) return { bg, text: 'text-indigo-50 drop-shadow-xl', bgImage, icon: renderIcon(<Cloud className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-gray-200 drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]" fill="currentColor" />, '☁️') };
    return { bg, text: 'text-white drop-shadow-xl', bgImage, icon: renderIcon(<Cloud className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.9)]" fill="currentColor" />, '⛅') };
  }
  if (condition === 'rainy') {
    if (isNight) return { bg, text: 'text-blue-100 drop-shadow-xl', bgImage, icon: renderIcon(<CloudRain className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-blue-200 drop-shadow-[0_0_25px_rgba(147,197,253,0.7)]" />, '🌧️') };
    return { bg, text: 'text-blue-50 drop-shadow-xl', bgImage, icon: renderIcon(<CloudRain className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-white drop-shadow-[0_0_30px_rgba(255,255,255,1)]" />, '🌧️') };
  }
  if (condition === 'snowy') {
    if (isNight) return { bg, text: 'text-indigo-50 drop-shadow-xl', bgImage, icon: renderIcon(<CloudSnow className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-white drop-shadow-[0_0_25px_rgba(255,255,255,0.8)]" />, '❄️') };
    return { bg, text: 'text-white drop-shadow-xl', bgImage, icon: renderIcon(<CloudSnow className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-white drop-shadow-[0_0_30px_rgba(255,255,255,1)]" fill="currentColor" />, '❄️') };
  }
  if (condition === 'foggy') {
    if (isNight) return { bg, text: 'text-gray-200 drop-shadow-xl', bgImage, icon: renderIcon(<CloudFog className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-gray-300 drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]" />, '🌫️') };
    return { bg, text: 'text-white drop-shadow-xl', bgImage, icon: renderIcon(<CloudFog className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-white drop-shadow-[0_0_30px_rgba(255,255,255,1)]" fill="currentColor" />, '🌫️') };
  }
  // storm
  return { bg, text: 'text-white drop-shadow-xl', bgImage, icon: renderIcon(<CloudLightning className="w-[30cqmin] h-[30cqmin] min-w-[32px] min-h-[32px] max-w-[120px] max-h-[120px] text-yellow-400 drop-shadow-[0_0_35px_rgba(250,204,21,0.9)]" />, '⛈️') };
}
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useState, useEffect } from 'react'
import toast from 'react-hot-toast'

import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from '@/components/ui/dialog'

import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel'

interface PostItCardProps {
  id: string
  content: string
  imageUrl?: string | null
  images?: string[]
  link?: string | null
  color: string
  font?: string
  pushpin?: string
  rotation: number
  userName: string
  authorId?: string
  categoryName: string
  createdAt: Date
  canDelete?: boolean
  onDelete?: (id: string) => void
  initialLikesCount?: number
  initialHasLiked?: boolean
  currentUserId?: string
  isLarge?: boolean
  initialViewsCount?: number
  initialSharesCount?: number
  onInteraction?: (isOpen: boolean) => void
  comments?: any[]
  triggerComponent?: React.ReactNode
  postitAppearance?: any
  ottModalBgType?: string
  ottModalBgColor?: string
  ottModalBgColorAlpha?: number
  ottModalBgImage?: string
  ottModalTextColor?: string
  ottCardRatio?: string
  textColor?: string | null
  textSize?: string | null
  isWeather?: boolean
  weatherTemp?: number
  weatherCondition?: string
  weatherBg?: string
  weatherDaily?: any
  weatherHourly?: any
}

const colorClasses: { [key: string]: string } = {
  YELLOW: 'bg-yellow-200 shadow-yellow-300/50',
  PINK: 'bg-pink-200 shadow-pink-300/50',
  BLUE: 'bg-blue-200 shadow-blue-300/50',
  GREEN: 'bg-green-200 shadow-green-300/50',
  ORANGE: 'bg-orange-200 shadow-orange-300/50',
  PURPLE: 'bg-purple-200 shadow-purple-300/50',
  WHITE: 'bg-white shadow-gray-200/50',
  DARK: 'bg-gray-900 border-gray-700 text-gray-100 shadow-gray-900/50',
  TRANSPARENT: 'bg-transparent shadow-none',
  GLASS: 'bg-white/30 backdrop-blur-md border border-white/40 shadow-xl',
}

const fontClasses: { [key: string]: string } = {
  HANDWRITING: 'font-handwriting',
  SERIF: 'font-serif',
  SANS: 'font-sans',
  MONO: 'font-mono',
  CURSIVE: 'font-cursive',
  SYSTEM: 'font-system',
  MODERN: 'font-modern',
  COMIC: 'font-comic',
}

const pushpinImages: { [key: string]: string } = {
  RED: '/pushpins/red.png',
  BLUE: '/pushpins/blue.png',
  GOLD: '/pushpins/gold.png',
  GREEN: '/pushpins/green.png',
  PINK: '/pushpins/pink.png',
  SILVER: '/pushpins/silver.png',
  BLACK: '/pushpins/clip.png',
  TAPE: '/pushpins/tape.png',
  NONE: '', // explicit missing
}

export function PostItCard({
  id,
  content,
  imageUrl,
  images = [],
  link,
  color,
  font = 'HANDWRITING',
  pushpin = 'RED',
  rotation,
  userName,
  categoryName,
  createdAt,
  canDelete,
  onDelete,
  initialLikesCount = 0,
  initialHasLiked = false,
  currentUserId,
  isLarge,
  initialViewsCount = 0,
  initialSharesCount = 0,
  onInteraction,
  comments = [],
  triggerComponent,
  postitAppearance,
  ottModalBgType,
  ottModalBgColor,
  ottModalBgColorAlpha,
  ottModalBgImage,
  ottModalTextColor,
  ottCardRatio,
  textColor,
  textSize,
  isWeather,
  weatherTemp,
  weatherCondition,
  weatherBg,
  weatherDaily,
  weatherHourly,
}: PostItCardProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const [likesCount, setLikesCount] = useState(initialLikesCount)
  const [viewsCount, setViewsCount] = useState(initialViewsCount)
  const [hasLiked, setHasLiked] = useState(initialHasLiked)
  const [hasViewed, setHasViewed] = useState(false)
  const [isLiking, setIsLiking] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [transitionEffect, setTransitionEffect] = useState<'flip-left' | 'flip-right' | 'fade'>('flip-left')
  const [isOpen, setIsOpen] = useState(false)

  const [commentsList, setCommentsList] = useState(comments)
  const [newComment, setNewComment] = useState('')
  const [isSubmittingComment, setIsSubmittingComment] = useState(false)
  const [isReporting, setIsReporting] = useState(false)

  const effects: ('flip-left' | 'flip-right' | 'fade')[] = ['flip-left', 'flip-right', 'fade']

  const handleOpenChange = async (open: boolean) => {
    if (open) {
      setIsOpen(true);
      if (typeof window !== 'undefined') {
        window.history.pushState({ modal_id: id }, '');
      }
      onInteraction?.(open);
      
      if (!hasViewed) {
        setHasViewed(true)
        setViewsCount((prev) => prev + 1)
        try {
          await fetch(`/api/postits/${id}/view`, { method: 'POST' })
        } catch (error) {
          console.error('View increment error', error)
        }
      }
    } else {
      setIsOpen(false);
      onInteraction?.(false);
      if (typeof window !== 'undefined' && window.history.state?.modal_id === id) {
        window.history.back();
      }
    }
  }

  useEffect(() => {
    const handlePopState = () => {
      if (isOpen) {
        setIsOpen(false);
        onInteraction?.(false);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [isOpen, onInteraction]);

  const handleLike = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!currentUserId) {
      toast.error('Beğenmek için giriş yapmalısınız')
      return;
    }
    if (isLiking) return;

    setIsLiking(true)
    const previousHasLiked = hasLiked;
    const previousLikesCount = likesCount;

    // Optimistic update
    setHasLiked(!hasLiked)
    setLikesCount((prev) => hasLiked ? prev - 1 : prev + 1)

    try {
      const response = await fetch(`/api/postits/${id}/like`, {
        method: 'POST',
      })
      if (!response.ok) {
        throw new Error('Bir hata oluştu')
      }
      const data = await response.json()
      setHasLiked(data.liked)
      // Actual count might need a refetch, but we just stick to optimistic for now
      // unless we want to query the exact count. 
    } catch (error) {
      console.error('Like error:', error)
      toast.error('İşlem başarısız')
      // Revert
      setHasLiked(previousHasLiked)
      setLikesCount(previousLikesCount)
    } finally {
      setIsLiking(false)
    }
  }

  const handleDelete = async () => {
    if (!onDelete) return
    setIsDeleting(true)
    try {
      await onDelete(id)
    } catch (error) {
      console.error('Delete error:', error)
      setIsDeleting(false)
    }
  }

  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.hash === `#postit-${id}-front-cover`) {
      const timer = setTimeout(() => {
        const el = document.getElementById(`postit-${id}-front-cover`)
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' })
          el.click()
        }
      }, 800)
      return () => clearTimeout(timer)
    }
  }, [id])

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation()
    try {
      const url = window.location.href.split('#')[0] + '#postit-' + id + '-front-cover'
      await navigator.clipboard.writeText(url)
      toast.success('Link kopyalandı')
    } catch (err) {
      toast.error('Kopyalanamadı')
    }
  }

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentUserId) {
      toast.error('Yorum yapmak için giriş yapmalısınız')
      return;
    }
    if (!newComment.trim()) return;

    setIsSubmittingComment(true)
    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postItId: id, content: newComment.trim() })
      })

      if (!response.ok) {
        throw new Error('Yorum eklenemedi')
      }

      const data = await response.json()
      setCommentsList(prev => [data.comment, ...prev])
      setNewComment('')
      toast.success('Yorum eklendi')
    } catch (error) {
      console.error('Comment error:', error)
      toast.error('Yorum eklenirken hata oluştu')
    } finally {
      setIsSubmittingComment(false)
    }
  }

  const handleDeleteComment = async (commentId: string) => {
    try {
      const response = await fetch(`/api/comments/${commentId}`, {
        method: 'DELETE'
      })
      if (!response.ok) throw new Error('Silinemedi')
      setCommentsList(prev => prev.filter(c => c.id !== commentId))
      toast.success('Yorum silindi')
    } catch (error) {
      toast.error('Yorum silinirken hata oluştu')
    }
  }

  const handleReport = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!currentUserId) {
      toast.error('Şikayet etmek için giriş yapmalısınız')
      return;
    }
    
    // Quick confirmation
    if (!window.confirm('Bu notu spam veya uygunsuz içerik olarak bildirmek istiyor musunuz?')) return;

    setIsReporting(true)
    try {
      const response = await fetch(`/api/postits/${id}/report`, { method: 'POST' })
      const data = await response.json()
      
      if (!response.ok) throw new Error(data.error || 'Şikayet edilemedi')
      
      toast.success(data.message || 'Şikayetiniz alındı')
      
      if (data.hidden && onDelete) {
         // Optionally remove it from view if it reached the auto-hide threshold
         onDelete(id)
      }
    } catch (error: any) {
      toast.error(error.message || 'Şikayet edilirken hata oluştu')
    } finally {
      setIsReporting(false)
    }
  }

  // Use provided images array, or fallback to imageUrl if array is empty but imageUrl exists
  const displayImages = images && images.length > 0 ? images : (imageUrl ? [imageUrl] : [])
  const hasMultipleImages = displayImages.length > 1

  const weatherUI = isWeather ? getWeatherUI(weatherBg || '', postitAppearance?.weatherIconSet, postitAppearance) : null;

  // Auto-play thumbnail slider if multiple images with random delays
  useEffect(() => {
    if (!hasMultipleImages) return

    // Randomized delay and interval to prevent synchronized transitions
    const initialDelay = Math.random() * 3000
    const intervalTime = 3000 + Math.random() * 2000

    const timeout = setTimeout(() => {
      const interval = setInterval(() => {
        setCurrentImageIndex((prev) => {
          // Select a random effect for the next transition
          const nextEffect = effects[Math.floor(Math.random() * effects.length)]
          setTransitionEffect(nextEffect)
          return (prev + 1) % displayImages.length
        })
      }, intervalTime)
      return () => clearInterval(interval)
    }, initialDelay)

    return () => clearTimeout(timeout)
  }, [hasMultipleImages, displayImages.length])

  const mainImage = displayImages[currentImageIndex] || displayImages[0]

  // Get motion props based on current effect
  const getMotionProps = () => {
    switch (transitionEffect) {
      case 'flip-left':
        return {
          initial: { rotateY: 90, opacity: 0 },
          animate: { rotateY: 0, opacity: 1 },
          exit: { rotateY: -90, opacity: 0 },
          style: { transformOrigin: 'left center' }
        }
      case 'flip-right':
        return {
          initial: { rotateY: -90, opacity: 0 },
          animate: { rotateY: 0, opacity: 1 },
          exit: { rotateY: 90, opacity: 0 },
          style: { transformOrigin: 'right center' }
        }
      default: // fade
        return {
          initial: { opacity: 0, scale: 0.95 },
          animate: { opacity: 1, scale: 1 },
          exit: { opacity: 0, scale: 1.05 },
          style: { transformOrigin: 'center center' }
        }
    }
  }

  const motionProps = getMotionProps()

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {triggerComponent ? (
          triggerComponent
        ) : (
          <motion.div
            id={`postit-${id}-front-cover`}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: '100px' }}
            exit={{ opacity: 0, scale: 0.8 }}
            whileHover={{ scale: 1.05, transition: { duration: 0.2 } }}
            style={{ rotate: postitAppearance?.animationStyle === 'flat' ? '0deg' : `${rotation}deg` }}
            className="relative cursor-pointer"
          >
            {/* Pushpin */}
            {pushpin !== 'NONE' && (
              <div className={`absolute ${pushpin === 'TAPE' ? '-top-3' : '-top-5'} left-1/2 -translate-x-1/2 z-10 ${pushpin === 'TAPE' ? 'opacity-80' : ''}`}>
                <Image
                  src={pushpinImages[pushpin] ?? pushpinImages.RED}
                  alt="Pin"
                  width={pushpin === 'TAPE' ? 60 : 45}
                  height={pushpin === 'TAPE' ? 30 : 45}
                  className="drop-shadow-md"
                />
              </div>
            )}

            <div
              className={`${(postitAppearance?.shapeType === 'custom' || postitAppearance?.shapeType === 'transparent') ? 'bg-transparent shadow-none border-none' : (isWeather && weatherUI ? weatherUI.bg : (colorClasses[color] ?? colorClasses.YELLOW))} 
                p-5 pt-8 transition-all duration-300 min-h-[180px] w-full h-full flex flex-col relative overflow-hidden
                ${isLarge || displayImages.length > 0 ? 'max-w-[800px]' : 'max-w-[400px]'}
                ${(!postitAppearance || !postitAppearance.shapeType || postitAppearance?.shapeType === 'default') ? 'rounded-md shadow-md hover:shadow-xl' : ''}
                ${postitAppearance?.shapeType === 'square' ? 'rounded-none shadow-md hover:shadow-xl' : ''}
                ${postitAppearance?.shapeType === 'circle' ? 'rounded-full aspect-square justify-center items-center pt-10 px-10 pb-6 text-center shadow-lg hover:shadow-xl' : ''}
                ${postitAppearance?.shapeType === 'paper_tear' ? 'rounded-b-2xl rounded-t-sm border-b-4 shadow-lg hover:shadow-xl' : ''}
                ${postitAppearance?.shapeType === 'custom' ? '!p-8 drop-shadow-xl' : ''}
              `}
              style={(postitAppearance?.shapeType === 'custom' && postitAppearance?.backgroundImage) ? {
                backgroundImage: `url(${postitAppearance.backgroundImage})`,
                backgroundSize: '100% 100%',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center'
              } : (isWeather && weatherUI?.bgImage ? {
                backgroundImage: `url('${weatherUI.bgImage}')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat'
              } : {})}
            >
              <div className={`relative z-10 flex flex-col h-full ${isWeather ? 'text-white' : ''} ${weatherUI?.bgImage ? 'bg-black/30 backdrop-blur-[2px] rounded-xl' : ''}`}>
              {/* Image Thumbnail (Automatic Slider if multiple) */}
              {displayImages.length > 0 && (
                <div
                  className="relative w-full aspect-video mb-4 rounded bg-gray-100 overflow-hidden shadow-inner"
                  style={{ perspective: '1200px' }}
                >
                  <AnimatePresence mode="popLayout">
                    <motion.div
                      key={currentImageIndex}
                      {...motionProps}
                      transition={{
                        duration: 0.8,
                        ease: [0.4, 0, 0.2, 1]
                      }}
                      style={{ ...motionProps.style, backfaceVisibility: 'hidden' }}
                      className="absolute inset-0"
                    >
                      {displayImages[currentImageIndex]?.match(/\.(mp4|webm|ogg)$/i) ? (
                        <div className="relative w-full h-full group/video">
                          <video
                            src={`${displayImages[currentImageIndex]}#t=0.1`}
                            className="object-contain w-full h-full block"
                            preload="metadata"
                            muted
                            playsInline
                          />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover/video:opacity-100 transition-opacity">
                            <Play className="w-12 h-12 text-white/80 fill-white/80" />
                          </div>
                        </div>
                      ) : (
                        <Image
                          src={displayImages[currentImageIndex]}
                          alt={`Post-it medya ${currentImageIndex + 1}`}
                          fill
                          className="object-contain"
                        />
                      )}
                    </motion.div>
                  </AnimatePresence>
                  {hasMultipleImages && (
                    <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full z-10 font-sans backdrop-blur-sm border border-white/20">
                      {currentImageIndex + 1} / {displayImages.length}
                    </div>
                  )}
                </div>
              )}

              {/* Content */}
              <div
                className={`mb-3 flex-grow flex flex-col ${
                  displayImages.length === 0 && !link && !isWeather
                    ? 'justify-center items-center text-center' 
                    : 'justify-start'
                } ${isWeather ? 'justify-center items-center h-full' : ''}`}
              >
                {isWeather && weatherUI ? (
                  <div style={{ containerType: 'size' }} className={`flex flex-col w-full h-full justify-start items-center p-2 sm:p-4 text-white relative z-10 ${weatherUI?.bgImage ? 'bg-black/30 rounded-xl backdrop-blur-sm' : ''}`}>
                    <h3 style={{ fontSize: 'clamp(14px, 7cqmin, 26px)' }} className="font-bold text-center tracking-wide mb-3 drop-shadow-md">
                      {content}&apos;{getSuffix(content)} Haftalık<br/>Hava Durumu Tahmini
                    </h3>
                    
                    {weatherDaily && weatherDaily.time && (
                      <div className="grid grid-cols-5 w-full h-full gap-0 sm:gap-1 drop-shadow-md mt-1">
                        {weatherDaily.time.slice(0, 5).map((dateStr: string, index: number) => {
                           const dateObj = new Date(dateStr);
                           const dayNum = dateObj.getDate();
                           const monthName = dateObj.toLocaleDateString('tr-TR', { month: 'long' });
                           const dayName = dateObj.toLocaleDateString('tr-TR', { weekday: 'long' });
                           
                           const min = Math.round(weatherDaily.temperature_2m_min[index]);
                           const max = Math.round(weatherDaily.temperature_2m_max[index]);
                           const code = weatherDaily.weather_code[index];
                           const dayStr = getConditionStr(code);
                           const dIcon = getWeatherUI(dayStr + '_day', postitAppearance?.weatherIconSet, postitAppearance).icon;
                           
                           return (
                             <div key={dateStr} className="flex flex-col items-center justify-start text-center border-r border-white/30 last:border-0 px-1 sm:px-2 w-full h-full tracking-tight">
                               <span style={{ fontSize: 'clamp(15px, 6cqmin, 24px)' }} className="font-bold leading-none">{dayNum}</span>
                               <span style={{ fontSize: 'clamp(9px, 3.5cqmin, 16px)' }} className="font-bold opacity-90 leading-tight mt-1 capitalize">{monthName}</span>
                               <span style={{ fontSize: 'clamp(9px, 3.5cqmin, 16px)' }} className="font-bold opacity-90 leading-tight capitalize">{dayName}</span>
                               
                               <div className="my-2 sm:my-3 scale-[0.4] sm:scale-[0.55] h-8 sm:h-12 flex items-center justify-center shrink-0">
                                  {dIcon}
                               </div>
                               
                               <span style={{ fontSize: 'clamp(8px, 3.2cqmin, 13px)' }} className="font-medium opacity-90 leading-none sm:leading-tight flex-grow flex items-start justify-center mt-1 w-full text-center">
                                  {getConditionDescTR(code)}
                               </span>
                               
                               <div className="mt-auto flex flex-col items-center gap-[2px] w-full pt-2">
                                 <span style={{ fontSize: 'clamp(12px, 5cqmin, 22px)' }} className="font-bold">{max}°C</span>
                                 <span style={{ fontSize: 'clamp(10px, 4cqmin, 16px)' }} className="font-semibold opacity-80 mb-1">{min}°C</span>
                               </div>
                             </div>
                           )
                        })}
                      </div>
                    )}
                  </div>
                ) : (
                  <p 
                    className={`whitespace-pre-wrap break-words w-full ${fontClasses[font] ?? fontClasses.HANDWRITING}`}
                    style={{ 
                      color: textColor || postitAppearance?.textColor || 'rgb(31, 41, 55)',
                      fontSize: ({ 'text-xs': '0.75rem', 'text-sm': '0.875rem', 'text-base': '1rem', 'text-lg': '1.125rem', 'text-xl': '1.25rem', 'text-2xl': '1.5rem', 'text-3xl': '1.875rem' } as any)[textSize || postitAppearance?.textSize] || (displayImages.length === 0 && !link ? '1.5rem' : '1rem')
                    }}
                  >
                    {content}
                  </p>
                )}
              </div>

              {/* Link Preview (Unclickable in front view to trigger modal instead) */}
              {(link && displayImages.length === 0) && (
                <div className="mb-4 overflow-hidden rounded-md border border-gray-300/40 relative z-10 bg-white/50 shadow-sm hover:shadow-md transition-shadow pointer-events-none flex justify-center items-center">
                  {link.match(/\.(jpeg|jpg|gif|png|webp|avif)$/i) ? (
                     <img src={link} className="w-full h-auto object-cover max-h-[300px] block" alt="Bağlantı Görseli" loading="lazy" />
                  ) : (
                    <CustomLinkPreview url={link} compact={isLarge} />
                  )}
                </div>
              )}

              <div className="flex items-center justify-between pt-3 border-t border-gray-400/30 mt-auto text-gray-600">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <div className="flex items-center gap-1.5 w-full">
                    <p className="font-semibold text-sm truncate">{userName}</p>
                    {authorId && <UserFollowButton userId={authorId} variant="icon" />}
                  </div>
                  <p className="text-gray-500 text-xs leading-tight">{categoryName}</p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5 text-gray-500">
                    <Eye className="w-6 h-6" />
                    <span className="font-medium text-sm font-sans">{viewsCount}</span>
                  </div>

                  <div
                    id={`postit-${id}-like-btn`}
                    onClick={handleLike}
                    className={`flex items-center gap-1.5 cursor-pointer transition-colors ml-1 ${hasLiked ? 'text-red-500' : 'hover:text-red-500'}`}
                  >
                    <Heart className={`w-6 h-6 ${hasLiked ? 'fill-red-500' : ''}`} />
                    <span className="font-medium text-sm font-sans">{likesCount}</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-gray-500 ml-1">
                    <MessageSquare className="w-6 h-6" />
                    <span className="font-medium text-sm font-sans">{commentsList.length}</span>
                  </div>

                  <PostitShareButton 
                    postitId={id} 
                    className="hover:text-blue-500 ml-1" 
                    iconClassName="w-6 h-6"
                    initialShareCount={initialSharesCount}
                  />

                  {canDelete && (
                    <div onClick={(e) => e.stopPropagation()}>
                      <Button
                        onClick={handleDelete}
                        disabled={isDeleting}
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-1 hover:bg-red-100 hover:text-red-600"
                      >
                        <Trash2 className="w-6 h-6" />
                      </Button>
                    </div>
                  )}

                  {!canDelete && currentUserId && (
                    <div
                      onClick={handleReport}
                      className={`flex items-center justify-center w-8 h-8 cursor-pointer text-gray-400 hover:bg-red-50 hover:text-red-500 rounded-md transition-colors ${isReporting ? 'opacity-50' : ''}`}
                      title="Şikayet Et"
                    >
                      <Flag className="w-6 h-6" />
                    </div>
                  )}
                </div>
              </div>
              </div> {/* End relative z-10 */}
            </div>
          </motion.div>
        )}
      </DialogTrigger>

      <DialogContent 
        className={`${isWeather && weatherUI && (!ottModalBgType || ottModalBgType === 'postit') ? weatherUI.bg : ((!ottModalBgType || ottModalBgType === 'postit') ? (colorClasses[color] ?? colorClasses.YELLOW) : 'bg-transparent')} ${ottCardRatio ? 'max-w-full h-[90vh] md:h-auto md:max-h-[90vh] w-auto' : 'max-w-3xl max-h-[90vh]'} overflow-y-auto border-none shadow-2xl p-0 gap-0 mx-auto`}
        style={{
          aspectRatio: (typeof window !== 'undefined' && window.innerWidth < 768 && ottCardRatio === '16/9') ? '9/16' : (ottCardRatio ? ottCardRatio.replace(':', '/') : undefined),
          backgroundColor: ottModalBgType === 'transparent' ? 'transparent' : ottModalBgType === 'semi-transparent' ? 'rgba(255, 255, 255, 0.7)' : ottModalBgType === 'color' ? (ottModalBgColor ? (
            ottModalBgColorAlpha !== undefined ? 
            (ottModalBgColor.startsWith('#') ? 
              `rgba(${parseInt(ottModalBgColor.slice(1,3),16)}, ${parseInt(ottModalBgColor.slice(3,5),16)}, ${parseInt(ottModalBgColor.slice(5,7),16)}, ${ottModalBgColorAlpha / 100})` 
              : ottModalBgColor)
            : ottModalBgColor
          ) : 'transparent') : (ottModalBgType === 'image' || ottModalBgType === 'gradient') ? 'transparent' : undefined,
          backgroundImage: (isWeather && weatherUI?.bgImage && (!ottModalBgType || ottModalBgType === 'postit')) ? `url(${weatherUI.bgImage})` : ((ottModalBgType === 'gradient' && ottModalBgColor) ? `linear-gradient(to right, ${ottModalBgColor.split(',')[0]}, ${ottModalBgColor.split(',')[1] || ottModalBgColor.split(',')[0]}, ${ottModalBgColor.split(',')[2] || ottModalBgColor.split(',')[0]})` : (ottModalBgType === 'image' && ottModalBgImage ? `url(${ottModalBgImage})` : undefined)),
          backgroundSize: (isWeather && weatherUI?.bgImage && (!ottModalBgType || ottModalBgType === 'postit')) ? 'cover' : ((ottModalBgType === 'image' && postitAppearance?.ottModalBgImageSize) ? postitAppearance.ottModalBgImageSize : 'cover'),
          backgroundPosition: (isWeather && weatherUI?.bgImage && (!ottModalBgType || ottModalBgType === 'postit')) ? 'center' : ((ottModalBgType === 'image' && postitAppearance?.ottModalBgImagePosition) ? postitAppearance.ottModalBgImagePosition : 'center'),
          backgroundRepeat: 'no-repeat',
          backdropFilter: (ottModalBgType === 'transparent' || ottModalBgType === 'semi-transparent') ? 'blur(8px)' : 'none'
        }}
      >
        <div className={`p-8 sm:p-12 relative min-h-full flex flex-col justify-start ${isWeather && weatherUI ? weatherUI.text : (ottModalTextColor || postitAppearance?.textColor ? '' : 'text-gray-800')} ${(isWeather && weatherUI?.bgImage && (!ottModalBgType || ottModalBgType === 'postit')) ? 'bg-black/30 backdrop-blur-sm' : ''}`} style={(!isWeather || !weatherUI) ? { backgroundColor: ottModalBgType === 'image' ? 'rgba(255,255,255,0.7)' : 'transparent', color: ottModalTextColor || postitAppearance?.textColor || undefined } : undefined}>

          {/* Pushpin for the modal too (hide in OTT mode) */}
          {!triggerComponent && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10 hidden sm:block">
              <Image
                src={pushpinImages[pushpin] ?? pushpinImages.RED}
                alt="Pin"
                width={60}
                height={60}
                className="drop-shadow-lg"
              />
            </div>
          )}

          <div className="flex flex-col gap-6">
            {/* Images: Carousel or Single */}
            {hasMultipleImages ? (
              <div className="w-full px-8">
                <Carousel className="w-full">
                  <CarouselContent>
                    {displayImages.map((imgUrl, index) => (
                      <CarouselItem key={index}>
                        <div className="relative w-full max-h-[60vh] flex items-center justify-center rounded-lg overflow-hidden shadow-sm bg-black/5">
                          {imgUrl?.match(/\.(mp4|webm|ogg)$/i) ? (
                            <div className="relative w-full flex justify-center">
                              <video
                                src={`${imgUrl}#t=0.1`}
                                className="max-h-[60vh] w-auto max-w-full object-contain block"
                                preload="metadata"
                                controls
                                playsInline
                              />
                            </div>
                          ) : (
                            <div className="relative w-full flex justify-center">
                              <img
                                src={imgUrl}
                                alt={`Post-it medya ${index + 1}`}
                                className="max-h-[60vh] w-auto max-w-full object-contain"
                                loading="lazy"
                              />
                            </div>
                          )}
                        </div>
                      </CarouselItem>
                    ))}
                  </CarouselContent>
                  <CarouselPrevious className="-left-4 bg-white/50 hover:bg-white" />
                  <CarouselNext className="-right-4 bg-white/50 hover:bg-white" />
                </Carousel>
              </div>
            ) : (
              mainImage && (
                  <div className="relative w-full max-h-[60vh] flex items-center justify-center rounded-lg overflow-hidden shadow-sm bg-black/5">
                    {mainImage?.match(/\.(mp4|webm|ogg)$/i) ? (
                      <div className="relative w-full flex justify-center">
                        <video
                          src={`${mainImage}#t=0.1`}
                          className="max-h-[60vh] w-auto max-w-full object-contain block"
                          preload="metadata"
                          controls
                          playsInline
                        />
                      </div>
                    ) : (
                      <div className="relative w-full flex justify-center">
                        <img
                          src={mainImage}
                          alt="Post-it medya"
                          className="max-h-[60vh] w-auto max-w-full object-contain"
                          loading="lazy"
                        />
                      </div>
                    )}
                </div>
              )
            )}

            {/* Content */}
            {isWeather && weatherUI ? (
                <div style={{ color: ottModalTextColor || postitAppearance?.textColor || 'white' }} className="flex flex-col items-center justify-start text-center gap-2 sm:gap-6 drop-shadow-2xl sm:py-4 mx-auto w-full relative z-10 flex-grow mb-8">
                   <h3 style={{ fontSize: 'clamp(20px, 3.5vw, 36px)' }} className="font-extrabold text-center tracking-wide mb-3 md:mb-5 drop-shadow-md">
                      {content}&apos;{getSuffix(content)} Haftalık<br/>Hava Durumu Tahmini
                   </h3>

                   <p className="w-full text-center font-medium opacity-90 mb-6 md:mb-10 leading-relaxed px-2 md:px-12 mx-auto drop-shadow-sm" style={{ fontSize: 'clamp(14px, 2vw, 18px)' }}>
                     Şu an {content} genelinde hava {weatherCondition?.toLocaleLowerCase('tr-TR')}, sıcaklık ise {Math.round(weatherTemp ?? 0)}°C seviyelerinde. Önümüzdeki 5 gün boyunca beklenen detaylı hava durumu tahmin tablosu aşağıdadır.
                   </p>
                   
                   {weatherDaily && weatherDaily.time && (
                     <div className="w-full flex flex-col px-0 md:px-4">
                        <div className="grid grid-cols-5 gap-1 md:gap-3 w-full drop-shadow-xl p-2 sm:p-4 bg-black/10 rounded-2xl border border-white/10">
                           {weatherDaily.time.slice(0, 5).map((dateStr: string, index: number) => {
                              const dateObj = new Date(dateStr);
                              const dayNum = dateObj.getDate();
                              const monthName = dateObj.toLocaleDateString('tr-TR', { month: 'long' });
                              const dayName = dateObj.toLocaleDateString('tr-TR', { weekday: 'long' });
                              
                              const min = Math.round(weatherDaily.temperature_2m_min[index]);
                              const max = Math.round(weatherDaily.temperature_2m_max[index]);
                              const code = weatherDaily.weather_code[index];
                              const dayStr = getConditionStr(code);
                              const dIcon = getWeatherUI(dayStr + '_day', postitAppearance?.weatherIconSet, postitAppearance).icon;
                              
                              return (
                                <div key={dateStr} className="flex flex-col items-center justify-start text-center border-r border-current/30 last:border-0 px-1 sm:px-3 h-full tracking-tight">
                                  <span style={{ fontSize: 'clamp(18px, 3vw, 32px)' }} className="font-bold leading-none mb-1">{dayNum}</span>
                                  <span style={{ fontSize: 'clamp(11px, 1.5vw, 18px)' }} className="font-bold opacity-90 leading-tight capitalize">{monthName}</span>
                                  <span style={{ fontSize: 'clamp(11px, 1.5vw, 18px)' }} className="font-bold opacity-90 leading-tight capitalize">{dayName}</span>
                                  
                                  <div className="my-2 sm:my-4 flex items-center justify-center shrink-0 w-full [&>*]:!w-10 [&>*]:!h-10 md:[&>*]:!w-16 md:[&>*]:!h-16 [&>*]:!min-w-0 [&>*]:!min-h-0 [&>*]:!max-w-none [&>*]:!max-h-none [&>span]:!text-[40px] md:[&>span]:!text-[64px]">
                                     {dIcon}
                                  </div>
                                  
                                  <span style={{ fontSize: 'clamp(10px, 1.4vw, 16px)' }} className="font-medium opacity-90 leading-relaxed flex-grow flex items-start justify-center">
                                     {getConditionDescTR(code)}
                                  </span>
                                  
                                  <div className="mt-auto flex flex-col items-center gap-1 w-full pt-4">
                                    <span style={{ fontSize: 'clamp(16px, 2.5vw, 24px)' }} className="font-bold">{max}°C</span>
                                    <span style={{ fontSize: 'clamp(12px, 1.8vw, 18px)' }} className="font-semibold opacity-80">{min}°C</span>
                                  </div>
                                </div>
                              )
                           })}
                        </div>
                     </div>
                   )}
                </div>
            ) : isWeather ? (
              <div className="flex flex-col items-center justify-center text-center gap-4 py-8 bg-black/20 rounded-2xl mx-auto w-full max-w-md text-white mb-8">
                <h3 className="text-3xl font-bold uppercase tracking-wider">{content}</h3>
                <div className="text-7xl font-black">{weatherTemp}°C</div>
                <p className="text-2xl font-medium">{weatherCondition}</p>
              </div>
            ) : (
              <div 
                className={`text-xl sm:text-2xl whitespace-pre-wrap break-words leading-relaxed ${fontClasses[font] ?? fontClasses.HANDWRITING}`}
                style={{ color: ottModalTextColor || postitAppearance?.textColor || 'rgb(17, 24, 39)' }}
              >
                {content}
              </div>
            )}

            {/* Link Preview inside Detail View (Hidden if there are images) */}
            {(link && displayImages.length === 0) && (
              <div className="mt-4 overflow-hidden rounded-xl border border-gray-300/40 bg-black/5 shadow-inner flex justify-center">
                {link.match(/\.(jpeg|jpg|gif|png|webp|avif|bmp)$/i) ? (
                   <img src={link} className="max-w-full h-auto max-h-[60vh] object-contain block mx-auto rounded-lg" alt="Bağlantı Görseli" />
                ) : (
                  <CustomLinkPreview url={link} compact={false} />
                )}
              </div>
            )}

            {/* Sub-info */}
            <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 pt-6 border-t ${ottModalTextColor || postitAppearance?.textColor ? 'border-current opacity-90' : 'border-black/10 text-gray-700'} text-sm mt-4`}>
              <div className="flex flex-col gap-1">
                <div className="font-bold text-lg flex items-center gap-3">
                  {userName} 
                  {authorId && <UserFollowButton userId={authorId} variant="button" />}
                </div>
                <div className={`${ottModalTextColor || postitAppearance?.textColor ? 'opacity-70' : 'opacity-80'}`}>{categoryName} • {createdAt.toLocaleDateString('tr-TR')}</div>
              </div>

              <div className="flex items-center gap-3">
                {link && (
                  <a
                    href={link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-blue-700 hover:text-blue-900 font-medium bg-white/50 px-4 py-2 rounded-full hover:bg-white/80 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Bağlantıyı Ziyaret Et</span>
                  </a>
                )}
                {canDelete && (
                  <Button
                    onClick={handleDelete}
                    disabled={isDeleting}
                    variant="destructive"
                    className="flex items-center gap-2 rounded-full shadow hover:bg-red-700 transition-colors px-4 py-2 h-auto text-sm"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Notu Sil</span>
                  </Button>
                )}
                {!canDelete && currentUserId && (
                  <Button
                    onClick={handleReport}
                    disabled={isReporting}
                    variant="outline"
                    className="flex items-center gap-2 rounded-full border-gray-300 text-gray-600 hover:bg-red-50 hover:text-red-600 hover:border-red-300 transition-colors px-4 py-2 h-auto text-sm bg-white/80"
                  >
                    <Flag className="w-4 h-4" />
                    <span>Şikayet Et</span>
                  </Button>
                )}
              </div>
            </div>
            
            {/* Comments Section */}
            <div className={`mt-8 pt-6 border-t ${ottModalTextColor || postitAppearance?.textColor ? 'border-current opacity-90' : 'border-black/10'}`}>
              <h3 className={`text-lg font-bold mb-4 flex items-center gap-2 ${ottModalTextColor || postitAppearance?.textColor ? '' : 'text-gray-800'}`}>
                <MessageSquare className="w-5 h-5" />
                Yorumlar ({commentsList.length})
              </h3>
              
              <div className="flex flex-col gap-4 mb-6 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                {commentsList.length === 0 ? (
                  <p className={`italic text-sm ${ottModalTextColor || postitAppearance?.textColor ? 'opacity-60' : 'text-gray-500'}`}>Henüz yorum yapılmamış. İlk yorumu siz yapın!</p>
                ) : (
                  commentsList.map((comment: any) => (
                    <div key={comment.id} className="bg-white/40 p-3 rounded-lg flex flex-col gap-1 shadow-sm font-sans">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs uppercase overflow-hidden shrink-0">
                            {comment.user?.image ? (
                              <Image src={comment.user.image} alt={comment.user.name || ''} width={24} height={24} className="object-cover w-full h-full" />
                            ) : (
                              (comment.user?.nickname || comment.user?.name || 'A')[0]
                            )}
                          </div>
                          <span className={`font-bold text-sm ${ottModalTextColor || postitAppearance?.textColor ? '' : 'text-gray-800'}`}>{comment.user?.nickname || comment.user?.name || 'Anonim'}</span>
                          <span className={`text-xs ${ottModalTextColor || postitAppearance?.textColor ? 'opacity-70' : 'text-gray-500'}`}>{new Date(comment.createdAt).toLocaleDateString('tr-TR')}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <button 
                            onClick={() => {
                              if (!currentUserId) {
                                toast.error('Beğenmek için giriş yapmalısınız');
                                return;
                              }
                              setCommentsList(prev => prev.map((c: any) => {
                                if (c.id === comment.id) {
                                  const hasLiked = c.likes?.length > 0;
                                  return {
                                    ...c,
                                    _count: { ...c._count, likes: hasLiked ? Math.max(0, (c._count?.likes || 0) - 1) : (c._count?.likes || 0) + 1 },
                                    likes: hasLiked ? [] : [{ userId: currentUserId }]
                                  }
                                }
                                return c;
                              }));
                              fetch(`/api/comments/${comment.id}/like`, { method: 'POST' }).catch(() => toast.error('İşlem başarısız'));
                            }}
                            className={`flex items-center gap-1 transition-colors p-1 ${comment.likes?.length > 0 ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
                            title="Yorumu beğen"
                          >
                            <Heart className={`w-3.5 h-3.5 ${comment.likes?.length > 0 ? 'fill-red-500' : ''}`} />
                            {(comment._count?.likes || 0) > 0 && <span className="text-xs">{comment._count.likes}</span>}
                          </button>
                          {(currentUserId === comment?.user?.id || canDelete) && (
                            <button 
                              onClick={() => handleDeleteComment(comment.id)}
                              className="text-red-400 hover:text-red-600 transition-colors p-1 flex items-center gap-1"
                              title="Yorumu sil"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                      <p className={`mt-1 text-sm md:ml-8 whitespace-pre-wrap ${ottModalTextColor || postitAppearance?.textColor ? '' : 'text-gray-700'}`}>{comment.content}</p>
                    </div>
                  ))
                )}
              </div>
              
              <form onSubmit={handleAddComment} className="flex gap-2">
                <Input 
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder={currentUserId ? "Yorumunuzu yazın..." : "Yorum yapmak için giriş yapmalısınız"}
                  disabled={!currentUserId || isSubmittingComment}
                  className="bg-white/50 border-white/20 focus:border-indigo-300 focus:ring-indigo-300 placeholder:text-gray-500"
                />
                <Button 
                  type="submit" 
                  disabled={!currentUserId || !newComment.trim() || isSubmittingComment}
                  className="shrink-0 bg-indigo-600 hover:bg-indigo-700 text-white border-0"
                >
                  <Send className="w-4 h-4 mr-2 hidden sm:block" />
                  Gönder
                </Button>
              </form>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
