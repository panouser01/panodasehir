'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Share2, Facebook, Twitter, Linkedin, MessageCircle, Link2 } from 'lucide-react';

interface CategoryShareButtonProps {
  categoryId: string;
}

export function CategoryShareButton({ categoryId }: CategoryShareButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const shareUrl = typeof window !== 'undefined' ? `${window.location.origin}/?category=${categoryId}` : '';

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleShare = (e: React.MouseEvent, platform: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!shareUrl) return;

    let url = '';
    switch (platform) {
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'twitter':
        url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareUrl)}`;
        break;
      case 'linkedin':
        url = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(shareUrl);
        alert('Link kopyalandı!');
        setIsOpen(false);
        return;
    }

    if (url) {
      window.open(url, '_blank', 'width=600,height=400');
      setIsOpen(false);
    }
  };

  return (
    <div className="relative inline-block" ref={dropdownRef}>
      <div 
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
        className="flex items-center justify-center px-1.5 py-0.5 rounded-md bg-green-100/90 text-green-800 shadow-sm transition-colors border border-green-500 hover:bg-green-200 cursor-pointer pointer-events-auto"
        title="Duvarı Paylaş"
      >
        <Share2 className="w-3 h-3" />
      </div>

      {isOpen && (
        <div 
          className="absolute z-50 right-0 mt-2 p-3 bg-white rounded-xl shadow-xl border border-gray-200 flex gap-3 w-max"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
        >
          <button onClick={(e) => handleShare(e, 'facebook')} className="p-3 bg-[#1877F2] text-white rounded-full hover:opacity-90 pointer-events-auto cursor-pointer transition-transform hover:scale-105" title="Facebook'ta Paylaş">
            <Facebook className="w-5 h-5" />
          </button>
          <button onClick={(e) => handleShare(e, 'twitter')} className="p-3 bg-[#1DA1F2] text-white rounded-full hover:opacity-90 pointer-events-auto cursor-pointer transition-transform hover:scale-105" title="Twitter'da Paylaş">
            <Twitter className="w-5 h-5" />
          </button>
          <button onClick={(e) => handleShare(e, 'whatsapp')} className="p-3 bg-[#25D366] text-white rounded-full hover:opacity-90 pointer-events-auto cursor-pointer transition-transform hover:scale-105" title="WhatsApp'ta Paylaş">
            <MessageCircle className="w-5 h-5" />
          </button>
          <button onClick={(e) => handleShare(e, 'linkedin')} className="p-3 bg-[#0A66C2] text-white rounded-full hover:opacity-90 pointer-events-auto cursor-pointer transition-transform hover:scale-105" title="LinkedIn'de Paylaş">
            <Linkedin className="w-5 h-5" />
          </button>
          <button onClick={(e) => handleShare(e, 'copy')} className="p-3 bg-gray-600 text-white rounded-full hover:opacity-90 pointer-events-auto cursor-pointer transition-transform hover:scale-105" title="Linki Kopyala">
            <Link2 className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}
