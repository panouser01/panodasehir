import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { type } = await req.json()

    // Determine which field to increment
    const updateData: any = {}
    if (type === 'view') {
      updateData.views = { increment: 1 }
    } else if (type === 'like') {
      updateData.likesCount = { increment: 1 }
    } else if (type === 'comment') {
      updateData.commentsCount = { increment: 1 }
    } else if (type === 'share') {
      updateData.sharesCount = { increment: 1 }
    } else {
      return NextResponse.json({ error: 'Invalid interaction type' }, { status: 400 })
    }

    const updatedArticle = await prisma.article.update({
      where: { id: params.id },
      data: updateData
    })

    return NextResponse.json(updatedArticle)
  } catch (error: any) {
    console.error('Error recording interaction:', error)
    return NextResponse.json(
      { error: 'Etkileşim kaydedilirken bir hata oluştu' },
      { status: 500 }
    )
  }
}
