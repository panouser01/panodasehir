'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Star, Wand2, Edit, Plus, FileText, ChevronRight, Eye, Heart, MessageSquare, Share2 } from 'lucide-react'
import ArticleEditorModal from './ArticleEditorModal'

interface ArticleGridProps {
  categoryId: string
  categoryName?: string
  postitAppearance?: any
  userRole?: string
  userId?: string
  canEdit?: boolean
}

export default function ArticleGrid({ categoryId, categoryName, postitAppearance, userRole, userId, canEdit: serverCanEdit = false }: ArticleGridProps) {
  const [articles, setArticles] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [isEditorOpen, setIsEditorOpen] = useState(false)
  const [editingArticle, setEditingArticle] = useState<any>(null)
  
  // Read mode (guest/viewer)
  const [isReadModalOpen, setIsReadModalOpen] = useState(false)
  const [readingArticle, setReadingArticle] = useState<any>(null)

  const handleInteract = async (e: React.MouseEvent, article: any, type: string) => {
    e.stopPropagation()
    
    // Optimizasyon için önce UI'ı güncelliyoruz
    setArticles(articles.map(a => {
      if (a.id === article.id) {
        return {
          ...a,
          views: type === 'view' ? (a.views || 0) + 1 : a.views,
          likesCount: type === 'like' ? (a.likesCount || 0) + 1 : a.likesCount,
          commentsCount: type === 'comment' ? (a.commentsCount || 0) + 1 : a.commentsCount,
          sharesCount: type === 'share' ? (a.sharesCount || 0) + 1 : a.sharesCount,
        }
      }
      return a
    }))

    try {
      await fetch(`/api/articles/${article.id}/interact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type })
      })
      if (type === 'share') {
        const url = `${typeof window !== 'undefined' ? window.location.origin : ''}/?category=${categoryId}&article=${article.id}`
        navigator.clipboard.writeText(url)
        // Toast can be added here if needed
      }
    } catch (err) {
      console.error(err)
    }
  }

  const canEdit = serverCanEdit || userRole === 'SUPER_ADMIN' || userRole === 'ADMIN' || userRole === 'EDITOR' || userRole === 'AUTHOR'

  const itemsPerRow = postitAppearance?.editorItemsPerRow || 3
  const imageRatio = postitAppearance?.editorImageRatio || '16/9'
  const cardBgColor = postitAppearance?.editorCardBgColor || '#ffffff'
  const titleColor = postitAppearance?.editorTitleColor || '#111827'
  const titleFont = postitAppearance?.editorTitleFont || 'sans-serif'
  const titleSize = postitAppearance?.editorTitleSize || 'xl'
  const starColor = postitAppearance?.editorStarColor || '#facc15'
  const cardStyle = postitAppearance?.editorCardStyle || 'modern' // modern, flat, bordered, glass

  const fetchArticles = async () => {
    try {
      const res = await fetch(`/api/articles?categoryId=${categoryId}`)
      if (res.ok) {
        const data = await res.json()
        setArticles(data)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (categoryId) {
      fetchArticles()
    }
  }, [categoryId])

  const handleSaveArticle = async (articleData: any) => {
    try {
      const isUpdate = !!articleData.id
      const url = isUpdate ? `/api/articles/${articleData.id}` : '/api/articles'
      const method = isUpdate ? 'PUT' : 'POST'

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(articleData)
      })

      if (res.ok) {
        fetchArticles()
      } else {
        throw new Error('Kaydedilemedi')
      }
    } catch (err) {
      throw err
    }
  }

  const handleArticleClick = (article: any) => {
    if (canEdit) {
      setEditingArticle(article)
      setIsEditorOpen(true)
    } else {
      setReadingArticle(article)
      setIsReadModalOpen(true)
    }
  }

  const getGridCols = () => {
    switch(itemsPerRow) {
      case 1: return 'grid-cols-1'
      case 2: return 'grid-cols-1 md:grid-cols-2'
      case 4: return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-4'
      case 5: return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5'
      case 3:
      default: return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
    }
  }

  const getRatioClass = () => {
    switch(imageRatio) {
      case '1/1': return 'aspect-square'
      case '4/3': return 'aspect-[4/3]'
      case '3/4': return 'aspect-[3/4]'
      case 'auto': return ''
      case '16/9':
      default: return 'aspect-video'
    }
  }

  const getFontFamily = () => {
    switch (titleFont) {
      case 'serif': return '"Playfair Display", ui-serif, Georgia, serif'
      case 'handwriting': return '"Caveat", cursive'
      case 'london': return '"London Presley", sans-serif'
      case 'puerto': return '"Puerto", sans-serif'
      case 'retosta': return '"Retosta", sans-serif'
      case 'sans-serif':
      default: return 'inherit'
    }
  }
  
  const getCardStyleClass = () => {
    switch (cardStyle) {
      case 'flat': return 'border-none shadow-none rounded-none'
      case 'bordered': return 'border-2 border-slate-900 shadow-[4px_4px_0_0_rgba(0,0,0,1)] rounded-xl'
      case 'glass': return 'bg-white/40 backdrop-blur-md border border-white/40 shadow-xl rounded-2xl'
      case 'modern':
      default: return 'border-gray-100 shadow-lg rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-1'
    }
  }

  return (
    <div className="w-full flex-col flex items-center mb-8 px-4 sm:px-0">
      
      {/* Create Button Header for Admins */}
      {canEdit && (
        <div className="w-full flex justify-start mb-6 max-w-7xl">
          <button
            onClick={() => {
              setEditingArticle(null)
              setIsEditorOpen(true)
            }}
            className="group flex flex-col sm:flex-row items-center gap-3 bg-white hover:bg-slate-50 border border-slate-200 px-6 py-3 rounded-2xl shadow-sm hover:shadow-md transition-all active:scale-95"
          >
            <div className="bg-pink-100 p-2 rounded-xl group-hover:bg-pink-200 transition-colors">
              <Plus className="w-5 h-5 text-pink-700" strokeWidth={2.5} />
            </div>
            <div className="text-left">
              <span className="block font-black text-slate-800 uppercase tracking-wider text-sm">Yeni Metin Yaz</span>
              <span className="hidden sm:block text-xs font-semibold text-slate-400">Okunabilir editör modunda yayınla</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-300 ml-2 group-hover:text-pink-500 transition-colors" />
          </button>
        </div>
      )}

      {/* Loading State */}
      {loading ? (
        <div className="w-full flex justify-center py-20 text-slate-400">
          <div className="flex flex-col items-center gap-2">
            <svg className="animate-spin h-8 w-8 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            <span className="text-sm font-semibold uppercase tracking-widest mt-2">Makaleler Yükleniyor...</span>
          </div>
        </div>
      ) : articles.length === 0 ? (
        <div className="w-full text-center py-20 bg-white/50 backdrop-blur border border-dashed border-slate-300 rounded-3xl max-w-4xl opacity-80 mt-4">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-xl font-bold text-slate-600">Henüz Yayımlanmış Metin Yok</h3>
          <p className="text-slate-500 mt-1">Bu kategori (duvar) için henüz bir okuma metni girilmemiş.</p>
        </div>
      ) : (
        <div className={`grid ${getGridCols()} gap-6 lg:gap-8 w-full max-w-[1400px]`}>
          {articles.map((article) => (
            <div 
              key={article.id}
              onClick={() => handleArticleClick(article)}
              className={`flex flex-col cursor-pointer transition-all duration-300 ${getCardStyleClass()}`}
              style={{ backgroundColor: cardStyle !== 'glass' ? cardBgColor : undefined }}
            >
              <div className={`w-full overflow-hidden relative bg-slate-100 ${getRatioClass()}`}>
                {article.thumbnailUrl ? (
                  <img src={article.thumbnailUrl} alt={article.title} className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-indigo-100 to-pink-100 flex items-center justify-center">
                    <FileText className="w-12 h-12 text-indigo-300 opacity-50" />
                  </div>
                )}
                {/* Author Badge */}
                {article.author?.name && (
                  <div className="absolute bottom-3 left-3 bg-white/10 backdrop-blur-md text-xs font-bold text-slate-800 px-3 py-1.5 rounded-full shadow-sm truncate max-w-[80%] flex items-center gap-2">
                    {article.author?.image && (
                      <img src={article.author.image} alt={article.author.name} className="w-5 h-5 rounded-full border border-slate-200" />
                    )}
                    <span className="truncate">{article.author.name}</span>
                  </div>
                )}
              </div>
              <div className="p-6 flex flex-col flex-1 justify-between">
                <div>
                  {/* Category Name Tag */}
                  {categoryName && (
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">{categoryName}</div>
                  )}

                  <h3 
                    className={`font-bold leading-snug mb-3 line-clamp-3`}
                    style={{ 
                      color: titleColor,
                      fontFamily: getFontFamily(),
                      fontSize: `var(--text-${titleSize}, 1.5rem)`, // approx
                    }}
                  >
                    {article.title}
                  </h3>
                  
                  {/* Intro/Summary Text if exists */}
                  <div 
                    className="text-slate-500 text-sm line-clamp-3 mb-4 leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: article.seoSummary || article.content.substring(0, 150) + '...' }}
                  />
                </div>

                <div className="flex flex-col gap-3 pt-4 border-t border-slate-100 mt-auto">
                  {/* Stats */}
                  <div className="flex items-center justify-between text-slate-600 px-1">
                    <button onClick={(e) => handleInteract(e, article, 'view')} className="flex items-center gap-1.5 hover:text-blue-500 transition-colors" title="Görüntülenme">
                      <Eye className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="font-bold text-sm">{article.views || 0}</span>
                    </button>
                    <button onClick={(e) => handleInteract(e, article, 'like')} className="flex items-center gap-1.5 hover:text-pink-500 transition-colors" title="Beğeni">
                      <Heart className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="font-bold text-sm">{article.likesCount || 0}</span>
                    </button>
                    <button onClick={(e) => handleInteract(e, article, 'comment')} className="flex items-center gap-1.5 hover:text-green-500 transition-colors" title="Yorumlar">
                      <MessageSquare className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="font-bold text-sm">{article.commentsCount || 0}</span>
                    </button>
                    <button onClick={(e) => handleInteract(e, article, 'share')} className="flex items-center gap-1.5 hover:text-indigo-500 transition-colors" title="Paylaşımlar">
                      <Share2 className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="font-bold text-sm">{article.sharesCount || 0}</span>
                    </button>
                  </div>

                  {/* Rating / Stars and Date */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5" style={{ color: starColor }}>
                      <Star className="w-5 h-5 fill-current" />
                      <span className="font-extrabold text-slate-700 text-lg">{article.averageRating > 0 ? article.averageRating.toFixed(1) : 'Yeni'}</span>
                    </div>

                    <div className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1.5 rounded-full shrink-0">
                      {new Date(article.createdAt).toLocaleDateString('tr-TR')}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      {isEditorOpen && (
        <ArticleEditorModal
          isOpen={isEditorOpen}
          onClose={() => {
            setIsEditorOpen(false)
            setEditingArticle(null)
          }}
          onSave={handleSaveArticle}
          initialData={editingArticle}
          categoryId={categoryId}
        />
      )}

      {/* ReadOnly Modal */}
      {isReadModalOpen && readingArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm shadow-2xl">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-full relative shrink-0 bg-white border-b border-slate-100 p-6 sm:px-10 sm:pt-10 sm:pb-6">
              <button 
                onClick={() => setIsReadModalOpen(false)}
                className="absolute top-4 right-4 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 rounded-full p-2 transition-colors"
                title="Kapat"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
              </button>

              <div className="w-full">
                <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-800 leading-tight pr-12" style={{ fontFamily: getFontFamily() }}>
                  {readingArticle.title}
                </h2>
                
                <div className="flex flex-wrap items-center gap-4 mt-6 text-slate-500 text-sm font-medium">
                  {readingArticle.author?.name && (
                    <div className="flex items-center gap-2">
                      {readingArticle.author.image ? (
                        <img src={readingArticle.author.image} alt={readingArticle.author.name} className="w-8 h-8 rounded-full shadow-sm" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-500 font-bold">
                          {readingArticle.author.name.charAt(0)}
                        </div>
                      )}
                      <span className="text-slate-700 font-semibold">{readingArticle.author.name}</span>
                    </div>
                  )}
                  
                  {readingArticle.author?.name && <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>}
                  
                  <span className="text-slate-500">{new Date(readingArticle.createdAt).toLocaleDateString('tr-TR')}</span>
                  
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                  
                  <span className="flex items-center gap-1.5 bg-yellow-50 text-yellow-700 px-3 py-1 rounded-full text-xs font-bold ring-1 ring-yellow-200/50">
                    <Star className="w-3.5 h-3.5 fill-yellow-500 text-yellow-500" />
                    {readingArticle.averageRating > 0 ? readingArticle.averageRating.toFixed(1) : 'Yeni'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 sm:p-10 bg-white">
              <div 
                className="prose prose-lg prose-slate max-w-none text-slate-800 leading-loose"
                dangerouslySetInnerHTML={{ __html: readingArticle.content }}
              />
            </div>
          </div>
        </div>
      )}

    </div>
  )
}
