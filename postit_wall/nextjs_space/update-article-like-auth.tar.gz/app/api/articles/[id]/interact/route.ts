import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Bu işlem için giriş yapmalısınız' }, { status: 401 })
    }

    const { type } = await req.json()
    const userId = (session.user as any).id

    if (type === 'view') {
      const updatedArticle = await prisma.article.update({
        where: { id: params.id },
        data: { views: { increment: 1 } }
      })
      return NextResponse.json(updatedArticle)
    } 
    
    if (type === 'like') {
      // Check if already liked
      const existingLike = await prisma.articleLike.findUnique({
        where: {
          articleId_userId: {
            articleId: params.id,
            userId: userId
          }
        }
      })

      if (existingLike) {
        return NextResponse.json({ error: 'Bunu zaten beğendiniz' }, { status: 400 })
      }

      await prisma.articleLike.create({
        data: {
          articleId: params.id,
          userId: userId
        }
      })

      const updatedArticle = await prisma.article.update({
        where: { id: params.id },
        data: { likesCount: { increment: 1 } }
      })
      return NextResponse.json(updatedArticle)
    } 
    
    if (type === 'share') {
      const updatedArticle = await prisma.article.update({
        where: { id: params.id },
        data: { sharesCount: { increment: 1 } }
      })
      return NextResponse.json(updatedArticle)
    }

    // fallback for comments if they somehow hit here directly
    if (type === 'comment') {
      return NextResponse.json({ error: 'Yorumlar okuma modalından yapılmalıdır' }, { status: 400 })
    }

    return NextResponse.json({ error: 'Geçersiz işlem' }, { status: 400 })

  } catch (error: any) {
    console.error('Error recording interaction:', error)
    return NextResponse.json(
      { error: 'Etkileşim kaydedilirken bir hata oluştu' },
      { status: 500 }
    )
  }
}

