'use client';

import React from 'react';
import { Share2, Facebook, Twitter, Linkedin, MessageCircle, Link2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface CategoryShareButtonProps {
  categoryId: string;
}

export function CategoryShareButton({ categoryId }: CategoryShareButtonProps) {
  const shareUrl = typeof window !== 'undefined' ? `${window.location.origin}/?category=${categoryId}` : '';

  const handleShare = (e: React.MouseEvent, platform: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!shareUrl) return;

    let url = '';
    switch (platform) {
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'twitter':
        url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        url = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareUrl)}`;
        break;
      case 'linkedin':
        url = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(shareUrl);
        alert('Link kopyalandı!');
        return;
    }

    if (url) {
      window.open(url, '_blank', 'width=600,height=400');
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <div 
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          className="flex items-center justify-center px-1.5 py-0.5 rounded-md bg-green-100/90 text-green-800 shadow-sm transition-colors border border-green-500 hover:bg-green-200 cursor-pointer"
          title="Duvarı Paylaş"
        >
          <Share2 className="w-3 h-3" />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-2" align="center" onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}>
        <div className="flex gap-2">
          <button onClick={(e) => handleShare(e, 'facebook')} className="p-2 bg-[#1877F2] text-white rounded-full hover:opacity-90" title="Facebook'ta Paylaş">
            <Facebook className="w-4 h-4" />
          </button>
          <button onClick={(e) => handleShare(e, 'twitter')} className="p-2 bg-[#1DA1F2] text-white rounded-full hover:opacity-90" title="Twitter'da Paylaş">
            <Twitter className="w-4 h-4" />
          </button>
          <button onClick={(e) => handleShare(e, 'whatsapp')} className="p-2 bg-[#25D366] text-white rounded-full hover:opacity-90" title="WhatsApp'ta Paylaş">
            <MessageCircle className="w-4 h-4" />
          </button>
          <button onClick={(e) => handleShare(e, 'linkedin')} className="p-2 bg-[#0A66C2] text-white rounded-full hover:opacity-90" title="LinkedIn'de Paylaş">
            <Linkedin className="w-4 h-4" />
          </button>
          <button onClick={(e) => handleShare(e, 'copy')} className="p-2 bg-gray-600 text-white rounded-full hover:opacity-90" title="Linki Kopyala">
            <Link2 className="w-4 h-4" />
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
