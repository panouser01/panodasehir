import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const comments = await prisma.articleComment.findMany({
      where: { articleId: params.id },
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: { id: true, name: true, nickname: true, image: true }
        }
      }
    })

    return NextResponse.json(comments)
  } catch (error) {
    console.error('Error fetching comments:', error)
    return NextResponse.json({ error: 'Yorumlar getirilemedi' }, { status: 500 })
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 })
    }

    const body = await req.json()
    const { content, isQuestion } = body

    if (!content || content.trim() === '') {
      return NextResponse.json({ error: 'İçerik boş olamaz' }, { status: 400 })
    }

    // 1. Create the comment/question
    const newComment = await prisma.articleComment.create({
      data: {
        content: content.trim(),
        isQuestion: Boolean(isQuestion),
        articleId: params.id,
        userId: (session.user as any).id,
      },
      include: {
        user: { select: { id: true, name: true, nickname: true, image: true } }
      }
    })

    // 2. Increment the associated counter on Article
    if (isQuestion) {
      await prisma.article.update({
        where: { id: params.id },
        data: { questionsCount: { increment: 1 } }
      })
    } else {
      await prisma.article.update({
        where: { id: params.id },
        data: { commentsCount: { increment: 1 } }
      })
    }

    return NextResponse.json(newComment, { status: 201 })
  } catch (error) {
    console.error('Error adding comment:', error)
    return NextResponse.json({ error: 'İşlem başarısız oldu' }, { status: 500 })
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const commentId = searchParams.get('commentId')

    if (!commentId) {
      return NextResponse.json({ error: 'Yorum ID eksik' }, { status: 400 })
    }

    const comment = await prisma.articleComment.findUnique({
      where: { id: commentId }
    })

    if (!comment) {
      return NextResponse.json({ error: 'Yorum bulunamadı' }, { status: 404 })
    }

    // Admins can delete any, users can delete their own
    const userRole = (session.user as any).role
    if (comment.userId !== (session.user as any).id && userRole !== 'ADMIN' && userRole !== 'SUPERADMIN' && userRole !== 'WALL_MANAGER') {
      return NextResponse.json({ error: 'Bu işlemi yapmaya yetkiniz yok' }, { status: 403 })
    }

    await prisma.articleComment.delete({
      where: { id: commentId }
    })

    // Decrement counter
    if (comment.isQuestion) {
      await prisma.article.update({
        where: { id: params.id },
        data: { questionsCount: { decrement: 1 } }
      })
    } else {
      await prisma.article.update({
        where: { id: params.id },
        data: { commentsCount: { decrement: 1 } }
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting comment:', error)
    return NextResponse.json({ error: 'Silme işlemi başarısız' }, { status: 500 })
  }
}
