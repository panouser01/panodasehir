import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useState, useEffect } from 'react'
import { Loader2, MessageSquare, HelpCircle, Trash2, Calendar } from 'lucide-react'
import { toast } from 'react-hot-toast'
import { Button } from '@/components/ui/button'

export default function ArticleCommentsModal({ isOpen, onClose, articleId, articleTitle }: { isOpen: boolean, onClose: () => void, articleId: string, articleTitle: string }) {
  const [comments, setComments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const loadComments = async () => {
    try {
      setLoading(true)
      const res = await fetch(`/api/articles/${articleId}/comments`)
      if (res.ok) {
        const data = await res.json()
        setComments(data)
      }
    } catch(err) {
      toast.error('Yorumlar yüklenemedi')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (isOpen && articleId) {
      loadComments()
    }
  }, [isOpen, articleId])

  const handleDelete = async (commentId: string) => {
    if(!confirm('Bunu silmek istediğinize emin misiniz?')) return
    try {
      const res = await fetch(`/api/articles/${articleId}/comments?commentId=${commentId}`, { method: 'DELETE' })
      if(res.ok) {
        toast.success('Başarıyla silindi')
        loadComments()
      } else {
        toast.error('Silinemedi')
      }
    } catch(err) {
      toast.error('Hata oluştu')
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold flex flex-col gap-2">
            <div>Etkileşim Yönetimi</div>
            <div className="text-sm font-normal text-slate-500 overflow-hidden text-ellipsis whitespace-nowrap" title={articleTitle}>📄 {articleTitle}</div>
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          </div>
        ) : comments.length === 0 ? (
          <div className="py-20 text-center flex flex-col items-center">
            <MessageSquare className="w-10 h-10 text-slate-300 mb-3" />
            <p className="text-slate-500 font-medium">Bu yazı için henüz yorum veya soru bulunmuyor.</p>
          </div>
        ) : (
          <div className="space-y-4 mt-4">
            {comments.map((c) => (
              <div key={c.id} className={`p-4 rounded-xl border ${c.isQuestion ? 'bg-pink-50 border-pink-100' : 'bg-slate-50 border-slate-200'} relative`}>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <img src={c.user?.image || "/img/user.png"} alt="" className="w-8 h-8 rounded-full object-cover" />
                    <div>
                      <div className="text-sm font-bold text-slate-800">{c.user?.nickname || c.user?.name || 'Anonim'}</div>
                      <div className="text-xs text-slate-500 flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> {new Date(c.createdAt).toLocaleDateString('tr-TR')}
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(c.id)} className="text-red-500 hover:text-red-600 hover:bg-red-50 h-8 px-2">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="mt-3">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase mb-2 ${c.isQuestion ? 'bg-pink-100 text-pink-700' : 'bg-indigo-100 text-indigo-700'}`}>
                    {c.isQuestion ? <><HelpCircle className="w-3 h-3"/> SORU</> : <><MessageSquare className="w-3 h-3"/> YORUM</>}
                  </span>
                  <p className="text-slate-700 text-sm whitespace-pre-wrap">{c.content}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
