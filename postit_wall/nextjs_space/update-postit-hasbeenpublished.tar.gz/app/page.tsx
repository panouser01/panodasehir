import React from 'react'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { PostItWall } from '@/components/postit/postit-wall'
import { OttSlider } from '@/components/postit/ott-slider'
import { PostItStack } from '@/components/postit/postit-stack'
import { ImageSlider } from '@/components/ui/image-slider'
import { EczanePopup } from '@/components/postit/eczane-popup'
import { HavaDurumuShortcut } from '@/components/postit/hava-durumu-shortcut'
import { redirect } from 'next/navigation'
import { ChevronLeft, ListTree, StickyNote, CalendarDays, Plus } from 'lucide-react'
import Link from 'next/link'
import { OttTopMenu } from '@/components/postit/ott-top-menu'
import { CalendarPopup } from '@/components/postit/calendar-popup'
import { PostItForm } from '@/components/forms/postit-form'
import { CategoryShareButton } from '@/components/postit/category-share-button'
import { CategorySubscribeButton } from '@/components/postit/category-subscribe-button'
import { CategoryMessageButton } from '@/components/postit/category-message-button'

import { getCachedCategories, filterActiveCategories, flattenCategories } from '@/lib/services/category.service'
import { unstable_cache } from 'next/cache'

interface HomePageProps {
  searchParams: { category?: string; from?: string; q?: string }
}

export default async function HomePage({ searchParams }: HomePageProps) {
  const session = await getServerSession(authOptions)
  const categoryId = searchParams?.category
  const fromId = searchParams?.from
  const searchQuery = searchParams?.q

  // Fetch root categories (without parent) with their children (CACHED)
  const allCategories = await getCachedCategories()

  const activeCategoriesTree = filterActiveCategories(allCategories)
  const categories = flattenCategories(activeCategoriesTree as any)

  // Get selected category for appearance settings
  let selectedCategory = categoryId
    ? categories.find(c => c.id === categoryId)
    : null

  // If someone lands on an inactive or non-existent category URL, bounce them to home
  if (categoryId && !selectedCategory) {
    redirect('/')
  }

  const getCachedAdsAndSettings = unstable_cache(
    async (catId: string | undefined) => {
      const now = new Date()
      const [activeAds, siteSettings, layoutConfig] = await Promise.all([
        prisma.ad.findMany({
          where: {
            isActive: true,
            AND: [
              { OR: [{ startDate: null }, { startDate: { lte: now } }] },
              { OR: [{ endDate: null }, { endDate: { gte: now } }] },
              { OR: [{ categoryId: catId || null }, { categoryIds: { array_contains: catId || 'root' } }] }
            ]
          }
        }),
        prisma.siteSettings.findUnique({
          where: { id: 'global' }
        }),
        (prisma as any).layoutConfig?.findUnique({
          where: { id: 'global' }
        }) || Promise.resolve({})
      ])
      return { activeAds, siteSettings, layoutConfig }
    },
    ['ads-and-settings'],
    { revalidate: 5, tags: ['site-settings', 'ads-and-settings'] } // Cache for 5 secs
  )

  const { activeAds, siteSettings: fetchedSiteSettings, layoutConfig: fetchedLayoutConfig } = await getCachedAdsAndSettings(categoryId)

  let siteSettings: any = fetchedSiteSettings
  if (!siteSettings) {
    siteSettings = {
      id: 'global',
      backgroundColor: '#cca378',
      backgroundImage: 'https://www.transparenttextures.com/patterns/cork-board.png',
      borderColor: '#6b4423',
      borderTopColor: '#8a5a2e',
      borderBottomColor: '#4a2f18',
      noBorder: false,
      isWallTransparent: false,
      isWallBackgroundRepeat: true,
      homeCategoryIds: [],
      heroBackgroundImage: null,
      isHeroTransparent: false,
      heroSubtitle: 'Fikirlerinizi paylaşın, topluluktaki diğerlerinin görüşlerini keşfedin',
      heroTitleFont: 'sans-serif',
      heroTitleColor: '#1f2937',
      heroTitleSize: '5xl',
      heroSubtitleFont: 'sans-serif',
      heroSubtitleColor: '#ffffff',
      heroSubtitleSize: 'xl',
      heroGradientFrom: '#facc15',
      heroGradientVia: '#f472b6',
      heroGradientTo: '#a855f7',
      heroAlignment: 'left',
      siteIsGradient: true,
      siteGradientFrom: '#fffbeb',
      siteGradientVia: '#fefce8',
      siteGradientTo: '#fff7ed',
      siteBackgroundColor: '#fffbeb',
      siteBackgroundImage: null,
      updatedAt: new Date()
    }
  }

  // Default appearance settings (now from global site settings)

  // Get selected category for appearance settings
  // (already defined as categoryId matching logic below)

  // If we are on home page (no category), try to find "Ana Duvar" to use its appearance
  const homeWall = categories.find(c => c.name === 'Ana Duvar') || null

  const isSet = (val: any) => val !== null && val !== undefined && val !== ''

  // Force appearance on the homepage to fallback entirely to Ana Duvar category, ensuring UI syncs
  const resolvedActiveWall = selectedCategory || homeWall; 

  // Use active wall appearance or fallback to SiteSettings
  const getValue = (prop: string, fallback: any) => {
    if (resolvedActiveWall && isSet(resolvedActiveWall[prop])) {
      return resolvedActiveWall[prop];
    }
    return isSet(siteSettings[prop]) ? siteSettings[prop] : fallback;
  }

  const appearance = {
    heroBackgroundImage: getValue('heroBackgroundImage', null),
    heroBackgroundStyle: getValue('heroBackgroundStyle', 'cover'),
    isHeroTransparent: getValue('isHeroTransparent', false),
    heroSubtitle: getValue('heroSubtitle', 'Fikirlerinizi paylaşın, topluluktaki diğerlerinin görüşlerini keşfedin'),
    hideHeroText: getValue('hideHeroText', false),
    heroTitleFont: getValue('heroTitleFont', 'sans-serif'),
    heroTitleColor: getValue('heroTitleColor', '#ffffff'),
    heroTitleSize: getValue('heroTitleSize', '5xl'),
    heroSubtitleFont: getValue('heroSubtitleFont', 'sans-serif'),
    heroSubtitleColor: getValue('heroSubtitleColor', '#ffffff'),
    heroSubtitleSize: getValue('heroSubtitleSize', 'xl'),
    heroAlignment: getValue('heroAlignment', 'left'),
    heroGradientFrom: getValue('heroGradientFrom', '#facc15'),
    heroGradientVia: getValue('heroGradientVia', '#f472b6'),
    heroGradientTo: getValue('heroGradientTo', '#a855f7'),
    categoryFont: getValue('categoryFont', 'sans-serif'),
    categoryColor: getValue('categoryColor', '#1f2937'),
    categoryBgColor: getValue('categoryBgColor', '#ffffff'),
    navMenuBgColor: getValue('navMenuBgColor', '#22c55e'),
    navMenuFont: getValue('navMenuFont', ''),
    navMenuTextColor: getValue('navMenuTextColor', '#ffffff'),
    navMenuFontSize: getValue('navMenuFontSize', 'md'),
    navMenuMainBold: getValue('navMenuMainBold', true),
    hideWallTitle: getValue('hideWallTitle', false),
    hideWallRibbon: getValue('hideWallRibbon', false),
    hideHeroPushpin: getValue('hideHeroPushpin', false),
    ribbonImage: getValue('ribbonImage', ''),
    ribbonColor: getValue('ribbonColor', '#502bb1'),
    ribbonTextColor: getValue('ribbonTextColor', '#ffffff'),
    ribbonTextFont: getValue('ribbonTextFont', 'sans-serif'),
    customRibbonText: getValue('customRibbonText', ''),
    postitAppearance: (() => {
      const raw = getValue('postitAppearance', null);
      if (typeof raw === 'string') {
        try { return JSON.parse(raw); } catch (e) { return null; }
      }
      return raw ? JSON.parse(JSON.stringify(raw)) : null;
    })()
  }

  // Resolve OTT Settings
  const getOttValue = (key: string, defaultValue: any) => {
    // Traverse from current selected category (or homeWall) up to the root
    let current = resolvedActiveWall;
    while (current) {
      const val = (current as any)[key];
      if (val !== undefined && val !== null && val !== '') return val;
      
      if (!current.parentId) break;
      const parent = categories.find(c => c.id === current!.parentId);
      if (!parent) break;
      current = parent;
    }
    
    // Fallback to global siteSettings
    const globalVal = (siteSettings as any)[key];
    return (globalVal !== undefined && globalVal !== null && globalVal !== '') ? globalVal : defaultValue;
  }

  const ottSettings = {
    isActive: !!getOttValue('isOttActive', false),
    itemsPerRow: getOttValue('ottItemsPerRow', 4),
    cardRatio: getOttValue('ottCardRatio', '16/9'),
    autoScrollSpeed: getOttValue('ottAutoScrollSpeed', 0),
    showTopMenu: getOttValue('ottShowTopMenu', true),
    showHeroSlider: getOttValue('ottShowHeroSlider', true),
    topMenuShape: getOttValue('ottTopMenuShape', 'circle'),
    showCategoryTitles: getOttValue('ottShowCategoryTitles', true),
    cardStyle: getOttValue('ottCardStyle', 'cover'),
    categoryTitleSize: getOttValue('ottCategoryTitleSize', '2xl'),
    categoryTitleColor: getOttValue('ottCategoryTitleColor', ''),
    categoryTitleAlignment: getOttValue('ottCategoryTitleAlignment', 'left'),
    categoryTitleFont: getOttValue('ottCategoryTitleFont', 'sans-serif'),
    separatorStyle: getOttValue('ottSeparatorStyle', 'none'),
    separatorColor: getOttValue('ottSeparatorColor', '#cbd5e1'),
    topMenuLabelBgColor: getOttValue('ottTopMenuLabelBgColor', ''),
    topMenuLabelHasBorder: getOttValue('ottTopMenuLabelHasBorder', false),
    topMenuIconBgColor: getOttValue('ottTopMenuIconBgColor', ''),
    cardBgType: getOttValue('ottCardBgType', 'postit'),
    cardBgColor: getOttValue('ottCardBgColor', ''),
    cardBgImage: getOttValue('ottCardBgImage', ''),
    modalBgType: getOttValue('ottModalBgType', 'postit'),
    modalBgColor: getOttValue('ottModalBgColor', ''),
    modalBgColorAlpha: getOttValue('ottModalBgColorAlpha', 70),
    modalBgImage: getOttValue('ottModalBgImage', ''),
    modalTextColor: getOttValue('ottModalTextColor', ''),
    topMenuMarqueeActive: getOttValue('ottTopMenuMarqueeActive', false),
    topMenuMarqueeSpeed: getOttValue('ottTopMenuMarqueeSpeed', 30)
  }

  // Resolve Logo Settings
  // Initial resolution from current wall/home wall
  let resolvedLogoUrl = selectedCategory ? selectedCategory.logoUrl : (homeWall ? homeWall.logoUrl : null)
  let resolvedLogoPosition = selectedCategory ? selectedCategory.logoPosition : (homeWall ? homeWall.logoPosition : 'top-right')
  let resolvedLogoSize = selectedCategory ? selectedCategory.logoSize : (homeWall ? homeWall.logoSize : 'medium')

  if (selectedCategory && selectedCategory.useParentLogo && selectedCategory.parentId) {
    const parentWall = categories.find(c => c.id === selectedCategory.parentId)
    if (parentWall) {
      resolvedLogoUrl = parentWall.logoUrl || null
      resolvedLogoPosition = parentWall.logoPosition || 'top-right'
      resolvedLogoSize = parentWall.logoSize || 'medium'
    }
  }

  const logoSettings = {
    url: resolvedLogoUrl,
    position: resolvedLogoPosition,
    size: resolvedLogoSize
  }

  // Pano (Board) Appearance settings - NO inheritance for sub-walls
  const boardAppearance = {
    isWallTransparent: getValue('isWallTransparent', false),
    isWallBackgroundRepeat: getValue('isWallBackgroundRepeat', true),
    isGradient: getValue('isGradient', false),
    backgroundColor: getValue('backgroundColor', '#cca378'),
    backgroundImage: getValue('backgroundImage', null),
    gradientFrom: getValue('gradientFrom', '#facc15'),
    gradientVia: getValue('gradientVia', '#f472b6'),
    gradientTo: getValue('gradientTo', '#a855f7'),
    noBorder: getValue('noBorder', false),
    noInnerBorder: getValue('noInnerBorder', false),
    isInnerTransparent: getValue('isInnerTransparent', false),
    innerBackgroundColor: getValue('innerBackgroundColor', '#E8DCC4'),
    borderColor: getValue('borderColor', '#6b4423'),
    borderTopColor: getValue('borderTopColor', '#8a5a2e'),
    borderBottomColor: getValue('borderBottomColor', '#4a2f18'),
  }

  // Site Ground (Zemin) Appearance - NO inheritance for sub-walls
  const siteAppearance = {
    backgroundColor: getValue('siteBackgroundColor', '#fffbeb'),
    backgroundImage: getValue('siteBackgroundImage', null),
    backgroundStyle: getValue('siteBackgroundStyle', 'repeat'),
    isGradient: getValue('siteIsGradient', true),
    gradientFrom: getValue('siteGradientFrom', '#fffbeb'),
    gradientVia: getValue('siteGradientVia', '#fefce8'),
    gradientTo: getValue('siteGradientTo', '#fff7ed'),
  }

  // Hero title - use category name if selected, otherwise if homeWall exists use its name, otherwise default
  const heroTitle = selectedCategory ? selectedCategory.name : (homeWall && homeWall.name === 'Ana Duvar' ? 'Ana Pano' : (homeWall ? homeWall.name : 'Panoda Şehir'))

  // Map size string to actual CSS size
  const titleSizeMap: Record<string, string> = {
    '4xl': '2.25rem',
    '5xl': '3rem',
    '6xl': '3.75rem'
  }

  const subtitleSizeMap: Record<string, string> = {
    'lg': '1.125rem',
    'xl': '1.25rem',
    '2xl': '1.5rem'
  }

  // Fetch post-its
  const where: any = {
    isApproved: true,
    isPublished: true,
    expiresAt: {
      gt: new Date()
    },
    content: {
      not: {
        startsWith: '[ÖZEL MESAJ]'
      }
    }
  }

  if (searchQuery) {
    where.content.contains = searchQuery
  }

  if (categoryId) {
    const getSubIds = (cat: any): string[] => {
      const ids = [cat.id]
      if (cat.children && cat.children.length > 0) {
        cat.children.forEach((child: any) => {
          ids.push(...getSubIds(child))
        })
      }
      return ids
    }
    const catNode = categories.find(c => c.id === categoryId)
    if (catNode) {
      const allRequiredIds = new Set<string>()

      // Kategorinin kendisi ve alt kategorileri
      getSubIds(catNode).forEach(id => allRequiredIds.add(id))

      // Seçili diğer duvarların (varsa) kendisi ve alt kategorileri
      let homeIds = catNode.homeCategoryIds || []
      if (typeof homeIds === 'string') {
        try { homeIds = JSON.parse(homeIds) } catch (e) { homeIds = [] }
      }
      if (Array.isArray(homeIds)) {
        homeIds.forEach((hId: string) => {
          const hNode = categories.find(c => c.id === hId)
          if (hNode) {
            getSubIds(hNode).forEach(id => allRequiredIds.add(id))
          }
        })
      }

      where.categoryId = { in: Array.from(allRequiredIds) }
    } else {
      where.categoryId = categoryId
    }
  }

  const currentUserId = (session?.user as any)?.id || ''

  const postitData = await prisma.postIt.findMany({
    where,
    include: {
      user: {
        select: {
          id: true,
          name: true,
          nickname: true,
          email: true,
          image: true
        }
      },
      category: {
        select: {
          id: true,
          name: true,
          postitAppearance: true,
          ottModalBgType: true,
          ottModalBgColor: true,
          ottModalBgColorAlpha: true,
          ottModalBgImage: true,
          ottModalTextColor: true
        }
      },
      PostItImage: {
        orderBy: {
          id: 'asc'
        }
      },
      comments: {
        include: {
          user: { select: { id: true, name: true, nickname: true, image: true } },
          likes: { where: { userId: currentUserId } },
          _count: { select: { likes: true } }
        },
        orderBy: { createdAt: 'desc' }
      },
      likes: {
        where: {
          userId: currentUserId
        }
      },
      _count: {
        select: {
          likes: true
        }
      }
    },
    orderBy: [
      {
        createdAt: 'desc'
      }
    ]
  })

  const organicPostits = postitData.map((postit: any) => {
    let safeAppearance = null;
    if (postit.category?.postitAppearance) {
      if (typeof postit.category.postitAppearance === 'string') {
        try { safeAppearance = JSON.parse(postit.category.postitAppearance); } catch(e) {}
      } else {
        safeAppearance = JSON.parse(JSON.stringify(postit.category.postitAppearance));
      }
    }
    
    let mappedPostit = { ...postit };

    // "ana sayfada yayınlanan postitler, parameterelerini 
    // ana sayfa duvarındaki OTT mod sayfasındaki değerlerden dinamik olarak alırlar aska kendi parametrelerine kaydetmezler."
    // Sadece ana sayfa (kategori filtresi yokken) görüntülendiğinde çalışır:
    if (!categoryId) {
       // Ana sayfanın genel OTT ayarlarından veya "Ana Duvar" postit Appearance'ından ezme işlemleri:
       const homeAppearance = appearance.postitAppearance || {};
       
       mappedPostit.color = homeAppearance.backgroundColor || mappedPostit.color;
       mappedPostit.font = homeAppearance.font || mappedPostit.font;
       mappedPostit.pushpin = homeAppearance.pinColor || mappedPostit.pushpin;

       // OTT modal ayarlarındaki text rengi önceliklidir, yoksa genel görünüm text rengi, o da yoksa postit kendi rengi.
       mappedPostit.textColor = ottSettings.isActive && ottSettings.modalTextColor
         ? ottSettings.modalTextColor
         : (homeAppearance.textColor || mappedPostit.textColor);

       mappedPostit.textSize = homeAppearance.textSize || mappedPostit.textSize;
    }

    return {
      ...mappedPostit,
      category: {
        ...postit.category,
        postitAppearance: safeAppearance
      },
      hasLiked: postit.likes.length > 0,
      likesCount: postit._count.likes
    };
  })

  const hasPosition = (ad: any, pos: string) => {
    try {
      if (Array.isArray(ad.positions)) {
        return ad.positions.includes(pos)
      } else if (typeof ad.positions === 'string') {
        const parsed = JSON.parse(ad.positions as string)
        return Array.isArray(parsed) && parsed.includes(pos)
      }
      return (ad as any).position === pos // Fallback for old data if needed
    } catch(e) {
      return (ad as any).position === pos
    }
  }

  const nativeAds = activeAds.filter(ad => hasPosition(ad, 'NATIVE'))
  const separatorAds = activeAds.filter(ad => hasPosition(ad, 'SEPARATOR'))
  const topAds = activeAds.filter(ad => hasPosition(ad, 'TOP_BANNER'))
  const bottomAds = activeAds.filter(ad => hasPosition(ad, 'BOTTOM_BANNER'))
  const leftAds = activeAds.filter(ad => hasPosition(ad, 'SIDEBAR_LEFT'))
  const rightAds = activeAds.filter(ad => hasPosition(ad, 'SIDEBAR_RIGHT'))
  const marqueeAds = activeAds.filter(ad => hasPosition(ad, 'MARQUEE'))
  const topMenuAds = activeAds.filter(ad => hasPosition(ad, 'TOP_MENU'))

  const postits: any[] = [...organicPostits]

  const injectNativeAds = (targetPostits: any[]) => {
    if (nativeAds.length === 0) return targetPostits;
    const combined = [...targetPostits];
    nativeAds.forEach((ad, index) => {
      const insertIndex = Math.min((index + 1) * 6, combined.length);
      if (insertIndex <= combined.length && combined.length > 0) {
        combined.splice(insertIndex, 0, {
          id: `ad-${ad.id}`,
          content: ad.title,
          link: ad.link,
          isAd: true,
          imageUrl: ad.imageUrl,
          color: 'YELLOW',
          font: 'HANDWRITING',
          pushpin: 'RED',
          rotation: (Math.random() - 0.5) * 10,
          user: { name: 'Sponsorlu' },
          category: { name: 'Reklam' },
          createdAt: ad.createdAt,
          categoryId: 'all'
        })
      }
    });
    return combined;
  };

  // Inject Weather ghosts if active wall is "Hava Durumu"
  if (resolvedActiveWall?.isSystem && resolvedActiveWall.name === 'Hava Durumu') {
    try {
      const weatherCities = await prisma.city.findMany({
        where: { showInWeather: true },
        orderBy: [{ weatherOrder: 'asc' }, { name: 'asc' }]
      })

      if (weatherCities.length > 0) {
        const { TURKEY_CITIES, getWeatherBackground, getWeatherConditionText } = await import('@/lib/weather')
        const validCities: any[] = []
        const lats: number[] = []
        const lons: number[] = []

        weatherCities.forEach(city => {
          const coords = TURKEY_CITIES[city.name]
          if (coords) {
            validCities.push(city)
            lats.push(coords.lat)
            lons.push(coords.lon)
          }
        })

        if (validCities.length > 0) {
          const params = new URLSearchParams({
            latitude: lats.join(','),
            longitude: lons.join(','),
            current: 'temperature_2m,weather_code,is_day',
            hourly: 'temperature_2m,weather_code,precipitation_probability,wind_speed_10m',
            daily: 'temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,wind_speed_10m_max',
            timezone: 'Europe/Istanbul'
          })
          
          const res = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`, {
            next: { revalidate: 3600 } // Cache API response for 1 hour to save hits
          })

          if (res.ok) {
            const wData = await res.json()
            const results = Array.isArray(wData) ? wData : [wData]
            
            validCities.forEach((city, idx) => {
              const current = results[idx]?.current
              if (current) {
                const temp = current.temperature_2m
                const code = current.weather_code
                
                postits.push({
                   id: `weather-${city.id}`,
                   content: `${city.name}`, // Title will be city name text
                   isWeather: true,
                   imageUrl: null, // No true image payload right now
                   color: 'BLUE', // default backup
                   font: 'SANS',
                   pushpin: 'NONE', // Special CSS styling for weather postits
                   rotation: (Math.random() - 0.5) * 6,
                   user: { name: 'Meteoroloji' },
                   category: { name: 'Hava Durumu', postitAppearance: appearance.postitAppearance },
                   createdAt: new Date(),
                   comments: [],
                   categoryId: resolvedActiveWall.id, // match
                   views: 0,
                   reportCount: 0,
                   likesCount: 0,
                   hasLiked: false,
                   textSize: 'xl',
                   textColor: '#1f2937', 
                   
                   // Weather-specific custom fields to render on postit cards
                   weatherTemp: temp,
                   weatherCondition: getWeatherConditionText(code),
                   weatherBg: `${getWeatherBackground(code)}_${current.is_day ? 'day' : 'night'}`,
                   weatherDaily: results[idx]?.daily || null,
                   weatherHourly: results[idx]?.hourly || null
                })
              }
            })
          }
        }
      }
    } catch (err) {
      console.error('Failed to generate weather postits', err)
    }
  }

  // Fetch slider for this category (or home page if category is null)
  // Fetch slider for this category (or home page if category is null)
  let homeCatId = null;
  if (!categoryId && homeWall) {
    homeCatId = homeWall.id;
  }
  
  let activeSlider: any = null;
  
  if (categoryId) {
    activeSlider = await prisma.slider.findFirst({
      where: { categoryId: categoryId, isActive: true }
    });
  } else {
    // Priority 1: Home Wall specific slider explicitly
    if (homeCatId) {
      activeSlider = await prisma.slider.findFirst({
        where: { categoryId: homeCatId, isActive: true }
      });
    }
    // Priority 2: Generic (Null) slider
    if (!activeSlider) {
      activeSlider = await prisma.slider.findFirst({
        where: { categoryId: null, isActive: true }
      });
    }
  }
  
  let sliderImages: string[] = []
  let sliderLinks: string[] = []

  if (activeSlider) {
    if (typeof activeSlider.images === 'string') {
      try { sliderImages = JSON.parse(activeSlider.images) } catch (e) {}
    } else if (Array.isArray(activeSlider.images)) {
      sliderImages = activeSlider.images
    }

    if (typeof activeSlider.links === 'string') {
      try { sliderLinks = JSON.parse(activeSlider.links) } catch (e) {}
    } else if (Array.isArray(activeSlider.links)) {
      sliderLinks = activeSlider.links
    }
  }

  const userRole = (session?.user as any)?.role
  const canDelete = userRole === 'SUPER_ADMIN'

  // Filter out empty images/links so next/image doesn't crash on empty string
  const validIndices = sliderImages.map((img, i) => img && img.trim() !== '' ? i : -1).filter(i => i !== -1)
  sliderImages = validIndices.map(i => sliderImages[i])
  sliderLinks = validIndices.map(i => sliderLinks[i] || '')

  // Category sliders should NOT fall back to global slider. 
  // Each category manages its own slider and its own background settings.

  // Fetch Calendar Data
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const todayStr = today.toISOString().split('T')[0];

  const activeCalendarCategories = await prisma.calendarCategory.findMany({
    where: { isActive: true },
    orderBy: { order: 'asc' }
  });

  const calendarDailyData: { categoryName: string; content: string; isWallSpecific?: boolean }[] = [];

  // Global Entries
  activeCalendarCategories.forEach(cat => {
    let entries: any[] = [];
    if (cat.globalEntries) {
      if (typeof cat.globalEntries === 'string') {
        try { entries = JSON.parse(cat.globalEntries); } catch (e) { }
      } else if (Array.isArray(cat.globalEntries)) {
        entries = cat.globalEntries;
      }
    }
    const todayEntry = entries.find(e => {
      const eDateStr = e.date ? (typeof e.date === 'string' ? e.date.split('T')[0] : new Date(e.date).toISOString().split('T')[0]) : '';
      return eDateStr === todayStr;
    });
    if (todayEntry?.content) {
      calendarDailyData.push({
        categoryName: cat.name,
        content: todayEntry.content
      });
    }
  });

  // Wall Specific Entries
  const activeWall = selectedCategory || homeWall;
  if (activeWall) {
    const wallEntries = await prisma.wallCalendarEntry.findMany({
      where: {
        categoryId: activeWall.id,
        date: {
          gte: today,
          lt: tomorrow
        }
      },
      include: {
        calendarCategory: true
      }
    });

    wallEntries.forEach(w => {
      calendarDailyData.push({
        categoryName: w.calendarCategory.name,
        content: w.content,
        isWallSpecific: true
      });
    });
  }

  // Calendar JSX
  const calendarLeaf = (
    <div className="flex flex-col items-center gap-2">
      <CalendarPopup dailyData={calendarDailyData} backgroundImage={siteSettings.calendarPopupBackgroundImage}>
        <div className="select-none transform rotate-3 hover:rotate-0 transition-all duration-500 group cursor-pointer">
          <div
            className={`rounded-lg shadow-xl border-2 border-gray-100 flex flex-col items-center relative transition-all duration-500 group-hover:-translate-y-1 ${siteSettings.calendarSize === 'large' ? 'min-w-[140px]' :
              siteSettings.calendarSize === 'small' ? 'min-w-[80px]' :
                'min-w-[110px]'
              }`}
            style={{
              backgroundColor: '#f4ecd8', // Samanlı kağıt rengi (Straw paper color)
              backgroundImage: `
                radial-gradient(circle at 2px 2px, rgba(0,0,0,0.02) 1px, transparent 0),
                linear-gradient(to bottom, transparent, rgba(0,0,0,0.02))
              `,
              backgroundSize: '4px 4px, 100% 100%'
            }}
          >
            {/* The curl triangle */}
            <div className="absolute bottom-0 right-0 w-0 h-0 border-solid border-b-transparent border-l-transparent transition-all duration-300 group-hover:border-b-[25px] group-hover:border-l-[25px] group-hover:border-b-[#f4ecd8] group-hover:border-l-gray-300 z-30 drop-shadow-[-2px_-2px_3px_rgba(0,0,0,0.2)]"></div>

            {/* The cut-out effect triangle */}
            <div className="absolute bottom-0 right-0 w-0 h-0 border-solid border-t-transparent border-r-transparent transition-all duration-300 group-hover:border-t-[25px] group-hover:border-r-[25px] group-hover:border-t-black/5 group-hover:border-r-black/5 z-10"></div>

            <div
              className="w-full py-1.5 px-3 text-center overflow-hidden rounded-t-md"
              style={{ backgroundColor: siteSettings.calendarColor || '#dc2626' }}
            >
              <span className={`text-white font-bold uppercase tracking-wider ${siteSettings.calendarSize === 'large' ? 'text-xs' :
                siteSettings.calendarSize === 'small' ? 'text-[8px]' :
                  'text-[10px]'
                }`}>
                {['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'][new Date().getMonth()]}
              </span>
            </div>
            <div className={`flex flex-col items-center pb-2 ${siteSettings.calendarSize === 'large' ? 'py-4 px-6' :
              siteSettings.calendarSize === 'small' ? 'py-1.5 px-3' :
                'py-3 px-4'
              }`}>
              <span className={`font-black text-amber-900/80 leading-none ${siteSettings.calendarSize === 'large' ? 'text-6xl' :
                siteSettings.calendarSize === 'small' ? 'text-3xl' :
                  'text-5xl'
                }`}>
                {new Date().getDate()}
              </span>
              <span className={`font-bold text-amber-800/60 uppercase ${siteSettings.calendarSize === 'large' ? 'text-sm mt-3' :
                siteSettings.calendarSize === 'small' ? 'text-[9px] mt-1' :
                  'text-[11px] mt-2'
                }`}>
                {['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'][new Date().getDay()]}
              </span>
            </div>
            {/* Spiral elements */}
            <div className="absolute -top-1 left-0 right-0 flex justify-around px-2">
              {[...Array(siteSettings.calendarSize === 'large' ? 5 : siteSettings.calendarSize === 'small' ? 3 : 4)].map((_, i) => (
                <div
                  key={i}
                  className={`${siteSettings.calendarSize === 'large' ? 'w-3 h-5' :
                    siteSettings.calendarSize === 'small' ? 'w-1.5 h-3' :
                      'w-2.5 h-4'
                    } bg-gray-400/50 rounded-full border border-gray-500/30 -mt-2 shadow-sm`}
                />
              ))}
            </div>
          </div>
        </div>
      </CalendarPopup>

      {/* Nöbetçi Eczaneler Linki / Pop-up */}
      <EczanePopup calendarSize={siteSettings.calendarSize} />
      {/* Hava Durumu Duvarı Hızlı Erişim (Masaüstü) */}
      <div className="mt-2">
        <HavaDurumuShortcut mobile={false} />
      </div>
    </div>
  );

  const clickableCalendarLeaf = calendarLeaf;

  const mobileCalendarBar = (
    <div className="sm:hidden w-full bg-gradient-to-r from-red-600 to-red-700 text-white shadow-md border-b-2 border-red-800 flex justify-between items-center px-4 py-2 relative z-[45]">
      <CalendarPopup dailyData={calendarDailyData} backgroundImage={siteSettings.calendarPopupBackgroundImage}>
        <div className="flex items-center gap-3 cursor-pointer group py-1">
          <CalendarDays className="w-7 h-7 text-white drop-shadow-md group-hover:scale-110 transition-transform pb-1" />
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-wider text-red-200 leading-none mb-0.5">Takvim & Etkinlikler</span>
            <span className="text-sm font-extrabold tracking-wide leading-none drop-shadow-sm">
              {`${new Date().getDate()} ${['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'][new Date().getMonth()]} ${['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'][new Date().getDay()]}`}
            </span>
          </div>
        </div>
      </CalendarPopup>
      <div className="flex items-center gap-2">
        <EczanePopup calendarSize="medium" />
        <div className="w-px h-6 bg-red-400/50 mx-1"></div>
        <HavaDurumuShortcut mobile={true} />
      </div>
    </div>
  )

  // Compute hero background style inline since we separate style properties
  const heroBackgroundImageValue = appearance.isHeroTransparent
    ? 'none'
    : (appearance.heroBackgroundImage
      ? `url('${appearance.heroBackgroundImage}')`
      : `linear-gradient(to right, ${appearance.heroGradientFrom}, ${appearance.heroGradientVia}, ${appearance.heroGradientTo})`)

  const bgStyle = appearance.heroBackgroundStyle || 'cover'
  const isCover = bgStyle.startsWith('cover')

  const heroBackgroundSizeValue = bgStyle === 'stretch' 
    ? '100% 100%' 
    : (isCover ? 'cover' : bgStyle === 'contain' ? 'contain' : 'auto')

  const heroBackgroundPositionValue = bgStyle === 'cover-top' ? 'top center'
    : bgStyle === 'cover-bottom' ? 'bottom center'
    : bgStyle === 'center' ? 'center'
    : (bgStyle === 'repeat' ? 'auto' : 'center')
  
  const heroBackgroundRepeatValue = bgStyle === 'repeat' ? 'repeat' : 'no-repeat'



  // Helper to render logo in multiple contexts if it matches
  const renderLogo = (context: 'page' | 'hero' | 'board') => {
    if (!logoSettings.url) return null;

    let pos = logoSettings.position || 'hero-top-right';
    // Backwards compatibility for legacy simple positions (map to hero by default)
    if (!pos.includes('-') && pos === 'center') pos = 'hero-center';
    else if (pos.startsWith('top-') || pos.startsWith('bottom-')) pos = 'hero-' + pos;

    if (!pos.startsWith(context + '-')) return null;

    let posClasses = '';
    if (pos.endsWith('-top-left')) posClasses = 'top-0 right-0 md:right-auto md:left-0';
    else if (pos.endsWith('-top-center')) posClasses = 'top-0 right-0 md:right-auto md:left-1/2 md:-translate-x-1/2';
    else if (pos.endsWith('-top-right')) posClasses = 'top-0 right-0';
    else if (pos.endsWith('-bottom-left')) posClasses = 'top-0 right-0 md:top-auto md:right-auto md:bottom-0 md:left-0';
    else if (pos.endsWith('-bottom-right')) posClasses = 'top-0 right-0 md:top-auto md:bottom-0';
    else posClasses = 'top-0 right-0 md:top-1/2 md:right-auto md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 opacity-100 md:opacity-20'; // center fallback

    const sizeClasses = logoSettings.size === 'small' ? 'h-8 md:h-16' :
      logoSettings.size === 'large' ? 'h-16 md:h-44' :
        logoSettings.size === 'xlarge' ? 'h-20 md:h-64' :
          logoSettings.size === 'mega' ? 'h-24 md:h-96' :
            'h-12 md:h-28'; // medium / fallback

    // Page is fixed on desktop. Hero/Board is absolute. Hide them entirely on mobile since we show the logo inline next to the title instead.
    const baseClasses = context === 'page' ? 'hidden md:block fixed z-[99999] p-4 md:p-6' : 'hidden md:block absolute z-[99999] p-4 md:p-6';

    return (
      <div className={`${baseClasses} pointer-events-none ${posClasses}`}>
        <img
          src={logoSettings.url}
          alt="Duvar Logosu"
          className={`object-contain drop-shadow-[0_0_15px_rgba(255,255,255,0.7)] ${sizeClasses}`}
        />
      </div>
    );
  };

  const renderStickyCalendar = (context: 'page' | 'hero' | 'board') => {
    if (siteSettings.calendarShow === false) return null;
    let pos = siteSettings.calendarPosition || 'right';
    
    // Sidebars are handled in the main flex container, not here
    if (pos === 'left' || pos === 'right') return null;

    if (!pos.startsWith(context + '-')) {
      if (context === 'page' && pos.startsWith('top-')) {
        // top-left, top-center, top-right map to 'page'
      } else {
        return null;
      }
    }

    let posClasses = '';
    if (pos.endsWith('-top-left') || pos === 'top-left') posClasses = 'top-4 left-4';
    else if (pos.endsWith('-top-center') || pos === 'top-center') posClasses = 'top-4 left-1/2 -translate-x-1/2';
    else if (pos.endsWith('-top-right') || pos === 'top-right') posClasses = 'top-4 right-4';
    else if (pos.endsWith('-bottom-left') || pos === 'bottom-left') posClasses = 'bottom-4 left-4';
    else if (pos.endsWith('-bottom-right') || pos === 'bottom-right') posClasses = 'bottom-4 right-4';

    const baseClasses = context === 'page' ? 'fixed z-[100]' : 'absolute z-40';

    return (
      <div className={`hidden sm:block ${baseClasses} ${posClasses}`}>
        {clickableCalendarLeaf}
      </div>
    );
  };

  return (
    <div
      className="min-h-screen"
      style={(() => {
        if (siteAppearance.backgroundImage) {
          const styleType = siteAppearance.backgroundStyle || 'repeat';
          let bgSize = 'auto';
          let bgRepeat = 'repeat';
          if (styleType === 'cover') { bgSize = 'cover'; bgRepeat = 'no-repeat'; }
          else if (styleType === 'stretch') { bgSize = '100% 100%'; bgRepeat = 'no-repeat'; }
          
          return {
            backgroundColor: siteAppearance.backgroundColor || '#fffbeb',
            backgroundImage: `url('${siteAppearance.backgroundImage}')`,
            backgroundPosition: 'top center',
            backgroundSize: bgSize,
            backgroundRepeat: bgRepeat,
            backgroundAttachment: 'fixed',
          }
        } else if (siteAppearance.isGradient) {
          return {
            backgroundImage: `linear-gradient(to bottom right, ${siteAppearance.gradientFrom || '#fffbeb'}, ${siteAppearance.gradientVia || '#fefce8'}, ${siteAppearance.gradientTo || '#fff7ed'})`,
          }
        } else {
          return {
            backgroundColor: siteAppearance.backgroundColor || '#fffbeb',
          }
        }
      })()}
    >
      {/* Page Logo Render */}
      {renderLogo('page')}

      {/* Top Fixed Calendar Section (Desktop Only) */}
      {renderStickyCalendar('page')}

      {/* Inline Calendar Bar (Mobile Only) */}
      {siteSettings.calendarShow !== false && mobileCalendarBar}

      {/* Hero / Slider Section */}
      {(!ottSettings.isActive || ottSettings.showHeroSlider) && (
        <div
          className={`relative w-full overflow-hidden ${((activeSlider as any)?.isTransparent || (appearance.isHeroTransparent && !activeSlider)) ? '' : 'shadow-md'}`}
        style={{
          backgroundColor: activeSlider 
            ? ((activeSlider as any)?.isTransparent ? 'transparent' : ((activeSlider as any)?.backgroundColor || '#f8f9fa'))
            : (appearance.isHeroTransparent ? 'transparent' : (boardAppearance.backgroundColor || undefined)),
          backgroundImage: activeSlider
            ? ((activeSlider as any)?.isTransparent
              ? 'none'
              : ((activeSlider as any)?.backgroundImage
                ? `url('${(activeSlider as any).backgroundImage}')`
                : ((activeSlider as any)?.isGradient
                  ? `linear-gradient(to right, ${(activeSlider as any)?.heroGradientFrom || '#facc15'}, ${(activeSlider as any)?.heroGradientVia || '#f472b6'}, ${(activeSlider as any)?.heroGradientTo || '#a855f7'})`
                  : 'none')))
            : heroBackgroundImageValue,
          backgroundSize: activeSlider ? (((activeSlider as any)?.backgroundImage) ? 'cover' : 'auto') : heroBackgroundSizeValue,
          backgroundPosition: activeSlider ? 'center' : heroBackgroundPositionValue,
          backgroundRepeat: activeSlider ? 'no-repeat' : heroBackgroundRepeatValue,
          borderTop: boardAppearance.noBorder ? 'none' : `12px solid ${boardAppearance.borderTopColor || boardAppearance.borderColor}`,
          borderBottom: boardAppearance.noBorder ? 'none' : `12px solid ${boardAppearance.borderBottomColor || boardAppearance.borderColor}`,
        }}
      >
        {/* Logo Render in Hero Section */}
        {renderLogo('hero')}
        {renderStickyCalendar('hero')}
        {activeSlider ? (
          <div className="w-full flex justify-center py-4 min-h-[160px]">
            {sliderImages.length > 0 && (
              <ImageSlider
                images={sliderImages}
                links={sliderLinks}
                className={`relative w-full max-w-[1170px] mx-auto h-[130px] sm:h-[160px] md:h-[200px] lg:h-[300px] rounded-xl ${((activeSlider as any)?.isTransparent) ? '' : 'shadow-md'}`}
              />
            )}
          </div>
        ) : (
          <div className={`relative py-12 flex flex-col justify-center h-full min-h-[160px] max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full ${appearance.heroAlignment === 'center' ? 'items-center' :
            appearance.heroAlignment === 'right' ? 'items-end' :
              'items-start'
            }`}>
            {!appearance.hideHeroText && (
              <div className={`relative z-10 bg-black/20 backdrop-blur-md p-6 sm:p-8 border border-white/10 rounded-2xl inline-block max-w-3xl shadow-2xl ${appearance.heroAlignment === 'center' ? 'text-center' :
                appearance.heroAlignment === 'right' ? 'text-right' :
                  'text-left'
                }`}>
                <div className={`mb-4 flex items-center md:block flex-wrap gap-3 ${appearance.heroAlignment === 'center' ? 'justify-center' : appearance.heroAlignment === 'right' ? 'justify-end' : 'justify-start'}`}>
                  {logoSettings.url && (
                    <img 
                      src={logoSettings.url} 
                      className="h-10 w-auto md:hidden object-contain" 
                      alt="Logo" 
                    />
                  )}
                  <h1
                    className="font-bold drop-shadow-xl md:mb-0 flex items-center gap-3 w-fit"
                    style={{
                      fontFamily: appearance.heroTitleFont,
                      color: appearance.heroTitleColor,
                      fontSize: titleSizeMap[appearance.heroTitleSize] || '3rem',
                      textShadow: '0 2px 4px rgba(0,0,0,0.5), 0 4px 12px rgba(0,0,0,0.3)',
                      margin: appearance.heroAlignment === 'center' ? '0 auto' : appearance.heroAlignment === 'right' ? '0 0 0 auto' : '0'
                    }}
                  >
                    {!appearance.hideHeroPushpin && "📌 "}{heroTitle}
                    {(selectedCategory || homeWall) && (
                      <CategorySubscribeButton categoryId={selectedCategory?.id || homeWall?.id!} className="ml-2" />
                    )}
                  </h1>
                </div>
                <p
                  className="mb-2 opacity-95 drop-shadow-lg font-medium"
                  style={{
                    fontFamily: appearance.heroSubtitleFont,
                    color: appearance.heroSubtitleColor,
                    fontSize: subtitleSizeMap[appearance.heroSubtitleSize] || '1.25rem',
                    textShadow: '0 1px 3px rgba(0,0,0,0.8)'
                  }}
                >
                  {selectedCategory?.description || appearance.heroSubtitle}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
      )}

      {/* Main Content */}
      <div className="w-full max-w-[1920px] mx-auto px-2 sm:px-4 pt-2 md:pt-4 pb-8">
        <div className={`flex flex-col gap-6 lg:gap-8 ${siteSettings.calendarPosition === 'left' ? 'lg:flex-row-reverse' : 'lg:flex-row'}`}>
          {/* Left Sidebar Ads */}
          {leftAds.length > 0 && (
            <aside className="hidden lg:flex flex-col w-[160px] xl:w-[200px] shrink-0">
              <div className="sticky top-24 flex flex-col gap-4">
                {leftAds.map((ad: any) => (
                  <a key={ad.id} href={ad.link} target="_blank" rel="noopener noreferrer" className="block relative bg-white border p-1 border-gray-200 shadow-sm rounded-md transition-transform hover:scale-105 group">
                    <span className="absolute -top-2 -right-2 bg-indigo-600 text-white text-[9px] px-1.5 py-0.5 rounded shadow z-10">Sponsorlu</span>
                    <img src={ad.imageUrl} alt={ad.title} className="w-full h-auto rounded" />
                  </a>
                ))}
              </div>
            </aside>
          )}

          {/* Post-it Wall with Corkboard Styling */}
          <main className="flex-1 w-full flex flex-col gap-2 min-w-0">
            {/* Top Banner Ads */}
            {topAds.length > 0 && (
              <div className="w-full flex flex-col gap-3 mb-4">
                {topAds.map((ad: any) => (
                  <a key={ad.id} href={ad.link} target="_blank" rel="noopener noreferrer" className="relative block w-full bg-white border border-gray-200 p-1 shadow-sm rounded-md transition-transform hover:scale-[1.01]">
                    <span className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded shadow z-10">Sponsorlu</span>
                    <img src={ad.imageUrl} alt={ad.title} className="w-full max-h-[120px] md:max-h-[200px] object-cover rounded" />
                  </a>
                ))}
              </div>
            )}

            {/* Sub-walls Marquee */}
            {(() => {
              const items = (selectedCategory ? selectedCategory.children : activeCategoriesTree) || [];
              let displayItems = items.filter((c: any) => c.name !== 'Ana Duvar');

              // Ana sayfa için TÜM ana kategorileri göster (orderedIds'yi yok say). 
              // Sadece alt sayfalardayken (selectedCategory varsa) özel sıralamayı dikkate al.
              if (selectedCategory) {
                let orderedIds = selectedCategory.homeCategoryIds || [];
                if (typeof orderedIds === 'string') { try { orderedIds = JSON.parse(orderedIds); } catch (e) { orderedIds = []; } }
                if (!Array.isArray(orderedIds)) orderedIds = [];

                if (orderedIds && orderedIds.length > 0) {
                  displayItems = orderedIds
                    .map((id: string) => categories.find((c: any) => c.id === id))
                    .filter(Boolean)
                    .filter((c: any) => c.name !== 'Ana Duvar');
                }
              }

              if (displayItems.length === 0) return null;

              // Sağda boşluk kalmaması için ekranı tamamen dolduracak kadar (yaklaşık 60-80 eleman)
              // tekrar sayısını garantiye alırken, kusursuz döngü için tekrar sayısını çift tutuyoruz (x2).
              const baseRepetitions = Math.max(1, Math.ceil(30 / displayItems.length));
              const repeatCount = baseRepetitions * 2;

              if (ottSettings.isActive && ottSettings.showTopMenu) {
                return (
                  <OttTopMenu 
                    displayItems={displayItems}
                    categoryId={categoryId || 'root'}
                    ottSettings={ottSettings}
                    boardAppearance={boardAppearance}
                    topMenuAds={topMenuAds}
                  />
                );
              } else if (ottSettings.isActive && !ottSettings.showTopMenu) {
                return null;
              }

              return (
                <div className="w-full bg-white/40 backdrop-blur-sm border-y border-black/10 py-2.5 overflow-hidden group">
                  <div className="relative flex overflow-x-hidden">
                    <div className="animate-marquee whitespace-nowrap">
                      {[...Array(repeatCount)].map((_, i) => (
                        <div key={i} className="flex shrink-0 items-center justify-start">
                          {displayItems.map((child: any) => (
                            <a
                              key={`${i}-${child.id}`}
                              href={`/?category=${child.id}&from=${categoryId || 'root'}`}
                              className="mx-10 text-lg font-bold text-gray-700 hover:text-blue-600 transition-colors flex items-center gap-2.5"
                            >
                              <span className="text-yellow-500 text-2xl">📌</span>
                              {child.name}
                            </a>
                          ))}
                          {marqueeAds.map((ad: any) => (
                            <a
                              key={`${i}-ad-${ad.id}`}
                              href={ad.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="mx-8 text-lg font-bold text-indigo-700 hover:text-indigo-900 transition-colors flex items-center gap-2.5"
                            >
                              <span className="bg-indigo-100 text-indigo-800 text-[13px] font-bold px-2.5 py-1 rounded shadow-sm border border-indigo-200">Sponsorlu</span>
                              {ad.title}
                            </a>
                          ))}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })()}

            <div
              className="w-full rounded-sm relative p-4 md:p-8 shadow-2xl flex-1"
              style={{
                backgroundColor: boardAppearance.isWallTransparent
                  ? 'transparent'
                  : boardAppearance.backgroundColor || '#cca378',
                backgroundImage: boardAppearance.isWallTransparent
                  ? 'none'
                  : (boardAppearance.isGradient
                    ? `linear-gradient(to right, ${boardAppearance.gradientFrom || '#facc15'}, ${boardAppearance.gradientVia || '#f472b6'}, ${boardAppearance.gradientTo || '#a855f7'})`
                    : (boardAppearance.backgroundImage ? `url("${boardAppearance.backgroundImage}")` : 'none')),
                backgroundSize: (!boardAppearance.isWallTransparent && !boardAppearance.isGradient && boardAppearance.backgroundImage) ? (boardAppearance.isWallBackgroundRepeat ? 'auto' : '100% auto') : undefined,
                backgroundRepeat: (!boardAppearance.isWallTransparent && !boardAppearance.isGradient && boardAppearance.backgroundImage) ? (boardAppearance.isWallBackgroundRepeat ? 'repeat' : 'no-repeat') : undefined,
                backgroundPosition: (!boardAppearance.isWallTransparent && !boardAppearance.isGradient && boardAppearance.backgroundImage) ? 'top center' : undefined,
                border: boardAppearance.noBorder ? '0px' : `18px solid ${boardAppearance.borderColor}`,
                borderBottomColor: boardAppearance.noBorder ? 'transparent' : boardAppearance.borderBottomColor,
                borderRightColor: boardAppearance.noBorder ? 'transparent' : boardAppearance.borderBottomColor,
                borderTopColor: boardAppearance.noBorder ? 'transparent' : boardAppearance.borderTopColor,
                borderLeftColor: boardAppearance.noBorder ? 'transparent' : boardAppearance.borderTopColor,
                boxShadow: boardAppearance.isWallTransparent
                  ? 'none'
                  : 'inset 0 0 30px rgba(0,0,0,0.6), 0 15px 25px rgba(0,0,0,0.15)',
                minHeight: '75vh'
              }}
            >
              {/* Back Button for Sub-Categories */}
              {(selectedCategory || fromId) && (
                <a
                  href={fromId ? (fromId === 'root' ? '/' : `/?category=${fromId}`) : (selectedCategory?.parentId ? `/?category=${selectedCategory.parentId}` : '/')}
                  className="absolute top-2 left-2 z-20 flex items-center justify-center w-8 h-8 md:w-10 md:h-10 bg-white/60 hover:bg-white/80 backdrop-blur-md rounded-full shadow-lg border border-black/5 transition-all hover:-translate-x-1 hover:scale-110 active:scale-90 group"
                  title="Geri Dön"
                >
                  <svg
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="w-5 h-5 md:w-6 md:h-6 text-gray-900 group-hover:text-blue-600 transition-colors"
                  >
                    <path d="M10 9V5L3 12L10 19V14.9C15 14.9 18.5 16.5 21 20C20 15 17 10 10 9Z" />
                  </svg>
                </a>
              )}

              {/* Logo Render in Board Section */}
              {renderLogo('board')}
              {renderStickyCalendar('board')}

              {(() => {
                const isCustomLayoutEnabled = !!getOttValue('useCustomLayout', false);
                const customLayoutData = getOttValue('customLayout', []);

                if (isCustomLayoutEnabled) {
                  let customLayout: any[] = [];
                  try {
                    customLayout = typeof customLayoutData === 'string' ? JSON.parse(customLayoutData) : (customLayoutData || []);
                  } catch (e) {
                    customLayout = [];
                  }

                  if (customLayout && customLayout.length > 0) {
                    return (
                      <div className="flex flex-row flex-wrap gap-x-[2%] gap-y-6 w-full mt-4">
                        {customLayout.map((block: any, idx: number) => {
                          let content = null;
                          let needsCorkFrame = false;

                          if (block.type === 'category_posts') {
                            const catPostitsRaw = block.categoryId ? injectNativeAds(organicPostits.filter((p: any) => p.categoryId === block.categoryId)) : [];
                            const catLimit = block.limit || 0;
                            const catPostits = catLimit > 0 ? catPostitsRaw.slice(0, catLimit) : catPostitsRaw;

                            // Inject NATIVE ads for this block
                            const injectedPostits = [...catPostits];
                            nativeAds.forEach((ad, adIdx) => {
                              const insertIndex = Math.min((adIdx + 1) * 6, injectedPostits.length);
                              injectedPostits.splice(insertIndex, 0, {
                                id: ad.id + '-' + idx + '-' + adIdx,
                                content: ad.title,
                                link: ad.link,
                                isAd: true, // Identify as Ad
                                imageUrl: ad.imageUrl,
                                color: 'YELLOW',
                                font: 'HANDWRITING',
                                pushpin: 'RED',
                                rotation: (Math.random() - 0.5) * 10,
                                user: { name: 'Sponsorlu' },
                                category: { name: 'Reklam' },
                                hasLiked: false,
                                likesCount: 0
                              })
                            })

                            content = <PostItStack postits={injectedPostits as any} canDelete={canDelete} currentUserId={currentUserId} />;
                            needsCorkFrame = !block.noInnerBorder;
                          } else if (block.type === 'custom_html') {
                            content = <div dangerouslySetInnerHTML={{ __html: block.htmlContent || '' }} className="w-full h-full p-4" />;
                          } else if (block.type === 'pharmacy_plugin') {
                            content = (
                              <div className="w-full h-[300px] bg-red-500/10 border-2 border-red-500 text-red-700 font-bold text-2xl flex flex-col items-center justify-center rounded-xl p-4 text-center">
                                ⚕️ Nöbetçi Eczaneler Alanı
                                <span className="text-sm font-normal mt-2">Bu modül ileride eklenecektir. (Placeholder)</span>
                              </div>
                            );
                          }

                          const blockWidth = block.width || 'full';
                          let widthClass = 'w-full';
                          if (blockWidth === 'half') widthClass = 'w-full md:w-[49%]';
                          if (blockWidth === 'third') widthClass = 'w-full md:w-[32%]';
                          if (blockWidth === 'twothird') widthClass = 'w-full md:w-[66%]';

                          let cumW = 0;
                          let showBanner = false;
                          for (let i = 0; i <= idx; i++) {
                            const bw = customLayout[i].width || 'full';
                            cumW += bw === 'half' ? 0.5 : bw === 'third' ? 0.33 : bw === 'twothird' ? 0.66 : 1;
                            if (cumW >= 0.95) {
                              if (i === idx) showBanner = true;
                              cumW = 0;
                            }
                          }
                          // Always show after the last element if a row was partially filled
                          if (idx === customLayout.length - 1 && cumW > 0) showBanner = true;

                          const currentRibbonColor = block.ribbonColor || appearance.ribbonColor || '#c40000';
                          const mappedCat = block.categoryId ? categories.find(c => c.id === block.categoryId) : null;
                          const currentRibbonImage = mappedCat?.ribbonImage || undefined;
                          const defaultBorderColor = '#8B5A2B';
                          const dynamicBorderColor = block.borderColor || defaultBorderColor;

                          return (
                            <React.Fragment key={idx}>
                              <div className={`${widthClass} flex flex-col mb-4 relative`}>
                                {/* Customizable Background */}
                              <div
                                className="absolute inset-0 z-0 bg-center bg-no-repeat rounded-xl opacity-100 pointer-events-none"
                                style={{
                                  backgroundImage: block.backgroundImage ? `url(${block.backgroundImage})` : 'none',
                                  backgroundSize: '100% 100%'
                                }}
                              />

                              {(block.title || block.titleImage) && (
                                <div className="relative flex justify-center w-full mt-2 mb-0 z-10">
                                  {block.titleImage ? (
                                    <Link href={block.categoryId ? `/?category=${block.categoryId}` : '#'} className="relative inline-flex items-center justify-center transform transition-transform duration-300 hover:scale-[1.05] -mt-2 cursor-pointer z-20">
                                      <img src={block.titleImage} alt={block.title || 'Başlık'} className="max-h-24 w-auto object-contain drop-shadow-lg" />
                                      {block.title && (
                                        <h3 className="absolute inset-0 flex items-center justify-center text-lg md:text-2xl font-black tracking-wide px-4 text-center leading-tight" style={{ color: block.ribbonTextColor || '#ffffff', fontFamily: "'Nunito', 'Segoe UI', system-ui, sans-serif", textShadow: '0 2px 4px rgba(0,0,0,0.8), 0 -1px 2px rgba(255,255,255,0.4)' }}>
                                          {block.title}
                                        </h3>
                                      )}
                                    </Link>
                                  ) : (
                                    <Link href={block.categoryId ? `/?category=${block.categoryId}` : '#'} className="relative inline-flex items-center justify-center group transform transition-transform duration-300 hover:scale-[1.05] cursor-pointer z-20">
                                      {/* Ribbon side folds */}
                                      {currentRibbonColor !== 'none' && (
                                        <>
                                          <div className="absolute top-2 -left-8 w-12 h-full -z-20 drop-shadow-md brightness-[0.65]" style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 25% 50%)' }} />
                                          <div className="absolute top-2 -right-8 w-12 h-full -z-20 drop-shadow-md brightness-[0.65]" style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 75% 50%, 100% 100%, 0 100%)' }} />
                                          <div className="absolute -bottom-2 left-0 w-4 h-2 -z-10 brightness-50" style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                                          <div className="absolute -bottom-2 right-0 w-4 h-2 -z-10 brightness-50" style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                                        </>
                                      )}

                                      <div className={currentRibbonColor !== 'none' ? "relative px-6 md:px-12 py-2 rounded-sm border-b-4 border-r-[3px] border-black/30 shadow-xl flex items-center gap-2" : "relative px-6 md:px-12 py-2 flex items-center gap-2"} style={currentRibbonColor !== 'none' ? { backgroundColor: currentRibbonColor, backgroundImage: currentRibbonImage ? `url('${currentRibbonImage}')` : undefined, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
                                        <h3 className="text-xl md:text-3xl font-black tracking-wide transition-colors duration-200" style={{ color: block.ribbonTextColor || (currentRibbonColor !== 'none' ? '#ffffff' : '#374151'), fontFamily: "'Nunito', 'Segoe UI', system-ui, sans-serif", textShadow: currentRibbonColor !== 'none' ? '0 2px 4px rgba(0,0,0,0.4), 0 -1px 1px rgba(255,255,255,0.2)' : 'none' }}>
                                          {block.title}
                                        </h3>
                                      </div>
                                    </Link>
                                  )}
                                </div>
                              )}

                              <div
                                className={`relative flex overflow-hidden transition-all duration-300 ${needsCorkFrame && !block.isTransparent ? 'shadow-[inset_0_0_20px_rgba(0,0,0,0.4),0_6px_12px_rgba(0,0,0,0.2)] rounded-sm' : ''} z-10 flex-1`}
                                style={{
                                  ...(needsCorkFrame && !block.isTransparent ? { border: `12px solid ${dynamicBorderColor}` } : {}),
                                  backgroundColor: block.isTransparent ? 'transparent' : (block.backgroundColor || (needsCorkFrame ? '#E8DCC4' : 'transparent'))
                                }}
                              >
                                {needsCorkFrame && !block.isTransparent && (
                                  <div className="absolute inset-0 opacity-40 mix-blend-multiply pointer-events-none" style={{ backgroundImage: 'url("/patterns/cork.png")', backgroundSize: '150px' }} />
                                )}
                                <div className="relative z-10 w-full p-2 h-full flex flex-col items-center">
                                  {content}
                                </div>
                              </div>
                            </div>

                            {/* Render SEPARATOR Ad after block if it completed a visual row */}
                            {separatorAds.length > 0 && showBanner && ((idx + 1) % ((separatorAds[idx % separatorAds.length] as any).frequency || 1) === 0) && (
                              <div className="w-full flex justify-center py-4 mb-2 -mt-2">
                                <a href={separatorAds[idx % separatorAds.length].link} target="_blank" rel="noopener noreferrer" className="relative block w-full bg-white border border-gray-200 p-1 shadow-sm rounded-md transition-transform hover:scale-[1.01]">
                                  <span className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded shadow z-10">Sponsorlu</span>
                                  <img src={separatorAds[idx % separatorAds.length].imageUrl} alt="Sponsor" className="w-full max-h-[120px] md:max-h-[180px] object-cover rounded" />
                                </a>
                              </div>
                            )}
                          </React.Fragment>
                        );
                      })}
                      </div>
                    );
                  }
                } // End Custom Layout Logic

                let wallSettingsIds = categoryId
                  ? (selectedCategory?.homeCategoryIds || [])
                  : (homeWall?.homeCategoryIds || []);

                if (typeof wallSettingsIds === 'string') {
                  try { wallSettingsIds = JSON.parse(wallSettingsIds); } catch (e) { wallSettingsIds = []; }
                }
                if (!Array.isArray(wallSettingsIds)) wallSettingsIds = [];

                if (wallSettingsIds.length > 0) {
                  const directPostits = categoryId ? postits.filter((p: any) => p.categoryId === categoryId) : [];
                  const currentWallLimit = categoryId ? (selectedCategory?.postitLimit || 0) : (homeWall?.postitLimit || 0);
                  const limitedDirectPostits = currentWallLimit > 0 ? directPostits.slice(0, currentWallLimit) : directPostits;

                  return (
                    <div className={`w-full mt-4 ${ottSettings.isActive ? 'flex flex-col gap-2' : 'space-y-12'}`}>
                      {limitedDirectPostits.length > 0 && (
                        <div className={ottSettings.isActive ? "mb-2" : "mb-12"}>
                          {ottSettings.isActive ? (
                            ottSettings.showCategoryTitles && (
                              <>
                                <div className={`relative flex ${ottSettings.categoryTitleAlignment === 'left' ? 'justify-start md:ml-12 ml-4' : ottSettings.categoryTitleAlignment === 'right' ? 'justify-end md:mr-12 mr-4' : 'justify-center'} w-full ${appearance.ribbonColor === 'none' ? 'mt-3 mb-1' : 'mt-4 mb-2'} z-10 transition-transform hover:scale-105 duration-300`}>
                                  <div className="relative inline-flex items-center justify-center group">
                                    {appearance.ribbonColor !== 'none' && (
                                      <>
                                        <div className="absolute top-3 -left-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                          style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 25% 50%)' }} />
                                        <div className="absolute top-3 -right-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                          style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 75% 50%, 100% 100%, 0 100%)' }} />
                                        <div className="absolute -bottom-3 left-0 w-6 h-3 -z-10 brightness-50"
                                          style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                                        <div className="absolute -bottom-3 right-0 w-6 h-3 -z-10 brightness-50"
                                          style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                                      </>
                                    )}
                                    <div className="flex items-center gap-3 relative z-30">
                                      <div className={appearance.ribbonColor !== 'none' ? "relative px-8 md:px-14 py-3 rounded-sm border-b-[6px] border-r-4 border-black/30 shadow-xl flex flex-col sm:flex-row items-center gap-3 decoration-transparent bg-cover bg-center" : `relative px-8 py-1 flex flex-col sm:flex-row items-center gap-3 decoration-transparent hover:scale-[1.02] transition-transform`} style={appearance.ribbonColor !== 'none' ? { backgroundColor: appearance.ribbonColor, backgroundImage: appearance.ribbonImage ? `url('${appearance.ribbonImage}')` : 'none' } : {}}>
                                        <div className="flex flex-row items-center gap-2 relative z-10 pointer-events-none">
                                          <div className="pointer-events-auto flex items-center pr-1">
                                            <PostItForm 
                                              categories={categories}
                                              defaultCategoryId={selectedCategory?.id || homeWall?.id!}
                                              userGroupIds={(session?.user as any)?.userGroupIds}
                                              userRole={(session?.user as any)?.role}
                                              customTrigger={
                                                <div className="bg-gradient-to-br from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 shadow-md border border-yellow-300 p-1 sm:p-1.5 rounded-lg cursor-pointer flex items-center justify-center hover:scale-110 transition-transform duration-300 mt-0.5" title="Kategoriye Post-it Ekle">
                                                  <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-950" strokeWidth={3} />
                                                </div>
                                              }
                                            />
                                          </div>
                                          <h2 className={`${ottSettings.categoryTitleSize === 'xl' ? 'text-xl md:text-2xl' : ottSettings.categoryTitleSize === '2xl' ? 'text-2xl md:text-3xl' : ottSettings.categoryTitleSize === '3xl' ? 'text-3xl md:text-4xl' : ottSettings.categoryTitleSize === '4xl' ? 'text-4xl md:text-5xl' : ottSettings.categoryTitleSize === '5xl' ? 'text-5xl md:text-6xl' : 'text-3xl md:text-5xl'} tracking-normal mb-0`}
                                            style={{
                                              color: ottSettings.categoryTitleColor || (appearance.ribbonTextColor === 'transparent' ? 'transparent' : (appearance.ribbonTextColor || (appearance.ribbonColor !== 'none' ? '#ffffff' : '#1f2937'))),
                                              textShadow: appearance.ribbonTextColor === 'transparent' ? 'none' : (appearance.ribbonColor !== 'none' ? '0 1px 0 rgba(255,255,255,0.3), 0 2px 0 rgba(255,255,255,0.2), 0 3px 0 rgba(255,255,255,0.1), 0 4px 0 rgba(0,0,0,0.1), 0 5px 0 rgba(0,0,0,0.15), 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15)' : 'none'),
                                              fontFamily: ottSettings.categoryTitleFont === 'handwriting' ? "'Caveat', cursive" : ottSettings.categoryTitleFont === 'london' ? "'London Presley', sans-serif" : ottSettings.categoryTitleFont === 'puerto' ? "'Puerto', sans-serif" : ottSettings.categoryTitleFont === 'retosta' ? "'Retosta', sans-serif" : ottSettings.categoryTitleFont === 'Dancing Script, cursive' ? "'Dancing Script', cursive" : "'Nunito', 'Segoe UI', system-ui, sans-serif",
                                              fontWeight: 900
                                            }}>
                                            {appearance.customRibbonText || selectedCategory?.name || 'Ana Duvar'}
                                          </h2>
                                          <div className="flex items-center gap-1.5 opacity-90 mt-1 pointer-events-auto cursor-default">
                                            <span className="text-[11px] bg-yellow-100/90 backdrop-blur-sm text-yellow-800 font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm border border-yellow-500">
                                              <StickyNote className="w-3 h-3" /> {directPostits.length}
                                            </span>
                                            {(selectedCategory || homeWall) && (
                                              <CategorySubscribeButton categoryId={selectedCategory?.id || homeWall?.id!} variant="badge" />
                                            )}
                                            {(selectedCategory || homeWall) && (
                                              <CategoryShareButton categoryId={selectedCategory?.id || homeWall?.id!} />
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                {ottSettings.separatorStyle !== 'none' && (
                                  <div className="w-full flex justify-center mt-0 mb-1">
                                    <div className="w-[95%] border-b-2" style={{ borderBottomStyle: ottSettings.separatorStyle as any, borderColor: ottSettings.separatorColor || '#cbd5e1' }} />
                                  </div>
                                )}
                              </>
                            )
                          ) : (
                            !appearance.hideWallTitle && (
                              <div className="relative flex justify-center w-full mt-6 mb-8 z-10 transition-transform hover:scale-105 duration-300">
                                <div className="relative inline-flex items-center justify-center group">
                                  {!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' && (
                                    <>
                                      <div className="absolute top-3 -left-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 25% 50%)' }} />
                                      <div className="absolute top-3 -right-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 75% 50%, 100% 100%, 0 100%)' }} />
                                      <div className="absolute -bottom-3 left-0 w-6 h-3 -z-10 brightness-50"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                                      <div className="absolute -bottom-3 right-0 w-6 h-3 -z-10 brightness-50"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                                    </>
                                  )}
                                  <div className={!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? "relative px-8 md:px-14 py-3 rounded-sm border-b-[6px] border-r-4 border-black/30 shadow-xl flex flex-col sm:flex-row items-center gap-3 decoration-transparent bg-cover bg-center" : "relative px-8 py-3 flex flex-col sm:flex-row items-center gap-3 decoration-transparent"} style={!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? { backgroundColor: appearance.ribbonColor, backgroundImage: appearance.ribbonImage ? `url(${appearance.ribbonImage})` : 'none' } : {}}>
                                    <h2 className={`relative z-10 text-3xl md:text-5xl tracking-normal mb-0 flex items-center gap-3`}
                                      style={{
                                        color: appearance.ribbonTextColor || (!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? '#ffffff' : '#1f2937'),
                                        textShadow: !appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? '0 1px 0 rgba(255,255,255,0.3), 0 2px 0 rgba(255,255,255,0.2), 0 3px 0 rgba(255,255,255,0.1), 0 4px 0 rgba(0,0,0,0.1), 0 5px 0 rgba(0,0,0,0.15), 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15)' : 'none',
                                        fontFamily: appearance.ribbonTextFont === 'cursive' ? "'Patrick Hand', cursive" : appearance.ribbonTextFont === 'serif' ? 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif' : appearance.ribbonTextFont === 'monospace' ? 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace' : appearance.ribbonTextFont === 'system-ui' ? 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif' : "'Nunito', 'Segoe UI', system-ui, sans-serif",
                                        fontWeight: 900
                                      }}>
                                      {appearance.customRibbonText || selectedCategory?.name || 'Ana Duvar'}
                                      {(selectedCategory || homeWall) && (
                                        <CategorySubscribeButton categoryId={selectedCategory?.id || homeWall?.id!} className="ml-2 scale-75 md:scale-100" />
                                      )}
                                    </h2>
                                  </div>
                                </div>
                              </div>
                            )
                          )}
                          <div
                            className={`relative flex overflow-hidden transition-all duration-300 ${!boardAppearance.noInnerBorder && !boardAppearance.isInnerTransparent ? 'shadow-[inset_0_0_20px_rgba(0,0,0,0.4),0_6px_12px_rgba(0,0,0,0.2)] rounded-sm' : ''} z-10 flex-1 w-full`}
                            style={{
                              ...(!boardAppearance.noInnerBorder && !boardAppearance.isInnerTransparent ? { border: `12px solid ${boardAppearance.borderColor || '#8B5A2B'}` } : {}),
                              backgroundColor: boardAppearance.isInnerTransparent ? 'transparent' : (boardAppearance.innerBackgroundColor || (!boardAppearance.noInnerBorder ? '#E8DCC4' : 'transparent'))
                            }}
                          >
                            {!boardAppearance.noInnerBorder && !boardAppearance.isInnerTransparent && (
                              <div className="absolute inset-0 opacity-40 mix-blend-multiply pointer-events-none" style={{ backgroundImage: 'url("/patterns/cork.png")', backgroundSize: '150px' }} />
                            )}
                            <div className="relative z-10 w-full p-2 h-full flex flex-col items-center">
                              {ottSettings.isActive ? (
                                <OttSlider
                                  initialPostits={limitedDirectPostits as any}
                                  canDelete={canDelete}
                                  currentUserId={(session?.user as any)?.id}
                                  postitAppearance={appearance.postitAppearance}
                                  ottItemsPerRow={ottSettings.itemsPerRow}
                                  ottCardRatio={ottSettings.cardRatio}
                                  ottAutoScrollSpeed={ottSettings.autoScrollSpeed}
                                  ottCardStyle={ottSettings.cardStyle}
                                  ottCardBgType={ottSettings.cardBgType}
                                  ottCardBgColor={ottSettings.cardBgColor}
                                  ottCardBgImage={ottSettings.cardBgImage}
                                  ottModalBgType={ottSettings.modalBgType}
                                  ottModalBgColor={ottSettings.modalBgColor}
                                  ottModalBgColorAlpha={ottSettings.modalBgColorAlpha}
                                  ottModalBgImage={ottSettings.modalBgImage}
                                  ottModalTextColor={ottSettings.modalTextColor}
                                />
                              ) : (
                                <PostItWall
                                  initialPostits={limitedDirectPostits as any}
                                  canDelete={canDelete}
                                  currentUserId={(session?.user as any)?.id}
                                  postitAppearance={appearance.postitAppearance}
                                  ottModalBgType={ottSettings.modalBgType}
                                  ottModalBgColor={ottSettings.modalBgColor}
                                  ottModalBgColorAlpha={ottSettings.modalBgColorAlpha}
                                  ottModalBgImage={ottSettings.modalBgImage}
                                  ottModalTextColor={ottSettings.modalTextColor}
                                  ottCardRatio={ottSettings.cardRatio}
                                />
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                      {wallSettingsIds.map((catId: string, index: number) => {
                        const cat = categories.find((c: any) => c.id === catId);
                        if (!cat) return null;
                        
                        if (typeof process !== 'undefined') {
                          try {
                            const fs = require('fs')
                            fs.appendFileSync('/tmp/SSR_DEBUG_MAP.txt', JSON.stringify({name: cat.name, appearance: cat.postitAppearance || 'MISSING_IN_MAP', raw: cat.postitAppearance}) + '\\n', 'utf8')
                          } catch(e) {}
                        }

                        const getCategoryIds = (c: any): string[] => {
                          const ids = [c.id];
                          if (c.children && c.children.length > 0) {
                            c.children.forEach((child: any) => {
                              ids.push(...getCategoryIds(child));
                            });
                          }
                          return ids;
                        };

                        const validIds = getCategoryIds(cat);
                        const catPostitsRaw = injectNativeAds(organicPostits.filter((p: any) => validIds.includes(p.categoryId)));
                        if (catPostitsRaw.length === 0) return null;

                        const catLimit = cat.postitLimit || 0;
                        const catPostits = catLimit > 0 ? catPostitsRaw.slice(0, catLimit) : catPostitsRaw;

                        const subcatCount = validIds.length - 1;
                        const postitCount = catPostitsRaw.length;

                        const currentRibbonColor = cat.ribbonColor || '#502bb1';
                        
                        const catOttIsActive = cat.isOttActive !== undefined && cat.isOttActive !== null ? cat.isOttActive : ottSettings.isActive;
                        const catOttItemsPerRow = cat.ottItemsPerRow || ottSettings.itemsPerRow;
                        const catOttCardRatio = cat.ottCardRatio || ottSettings.cardRatio;
                        const catOttAutoScrollSpeed = cat.ottAutoScrollSpeed !== undefined && cat.ottAutoScrollSpeed !== null ? cat.ottAutoScrollSpeed : ottSettings.autoScrollSpeed;
                        const catOttCardStyle = cat.ottCardStyle || ottSettings.cardStyle;
                        const catOttCardBgType = cat.ottCardBgType || ottSettings.cardBgType;
                        const catOttCardBgColor = cat.ottCardBgColor || ottSettings.cardBgColor;
                        const catOttCardBgImage = cat.ottCardBgImage || ottSettings.cardBgImage;
                        const catOttModalBgType = cat.ottModalBgType || ottSettings.modalBgType;
                        const catOttModalBgColor = cat.ottModalBgColor || ottSettings.modalBgColor;
                        const catOttModalBgColorAlpha = cat.ottModalBgColorAlpha !== undefined && cat.ottModalBgColorAlpha !== null ? cat.ottModalBgColorAlpha : ottSettings.modalBgColorAlpha;
                        const catOttModalBgImage = cat.ottModalBgImage || ottSettings.modalBgImage;
                        const catOttModalTextColor = cat.ottModalTextColor || ottSettings.modalTextColor;

                        const activeAlignment = catOttIsActive ? (cat.ottCategoryTitleAlignment || ottSettings.categoryTitleAlignment) : (cat.ribbonAlignment || 'center');
                        
                        const sizeMap: Record<string, string> = {
                          'xl': 'text-xl md:text-2xl',
                          '2xl': 'text-2xl md:text-3xl',
                          '3xl': 'text-3xl md:text-4xl',
                          '4xl': 'text-4xl md:text-5xl',
                          '5xl': 'text-5xl md:text-6xl'
                        };
                        const activeTitleSize = catOttIsActive && ottSettings.categoryTitleSize ? (sizeMap[ottSettings.categoryTitleSize] || 'text-3xl md:text-5xl') : 'text-3xl md:text-5xl';
                        const activeTitleColor = (catOttIsActive && ottSettings.categoryTitleColor) ? ottSettings.categoryTitleColor : (cat.ribbonTextColor === 'transparent' ? 'transparent' : (cat.ribbonTextColor || (currentRibbonColor !== 'none' ? '#ffffff' : '#1f2937')));

                        const activeTitleFontRaw = catOttIsActive ? ((cat.ottCategoryTitleFont && cat.ottCategoryTitleFont !== 'sans-serif') ? cat.ottCategoryTitleFont : (ottSettings.categoryTitleFont || 'sans-serif')) : (cat.ribbonTextFont || 'sans-serif');
                        const activeTitleFont = activeTitleFontRaw === 'handwriting' ? "'Caveat', cursive" : activeTitleFontRaw === 'london' ? "'London Presley', sans-serif" : activeTitleFontRaw === 'puerto' ? "'Puerto', sans-serif" : activeTitleFontRaw === 'retosta' ? "'Retosta', sans-serif" : activeTitleFontRaw === 'Dancing Script, cursive' ? "'Dancing Script', cursive" : "'Nunito', 'Segoe UI', system-ui, sans-serif";

                        const isTransparent = currentRibbonColor === 'none';
                        const catOttShowCategoryTitles = cat.ottShowCategoryTitles !== undefined && cat.ottShowCategoryTitles !== null ? cat.ottShowCategoryTitles : ottSettings.showCategoryTitles;

                        return (
                          <div key={cat.id} className={catOttIsActive ? "flex flex-col gap-1" : "space-y-4"}>
                            {(!catOttIsActive || catOttShowCategoryTitles) && (
                              <div className={`relative flex ${activeAlignment === 'left' ? 'justify-start md:ml-12 ml-4' : activeAlignment === 'right' ? 'justify-end md:mr-12 mr-4' : 'justify-center'} w-full ${catOttIsActive ? (isTransparent ? 'mt-3 mb-1' : 'mt-4 mb-2') : 'mt-6 mb-8'} z-10 transition-transform hover:scale-105 duration-300`}>
                                <div className="relative inline-flex items-center justify-center group">

                                {/* Ribbon Left Tail */}
                                {currentRibbonColor !== 'none' && (
                                  <>
                                    <div className="absolute top-3 -left-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                      style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 25% 50%)' }} />

                                    <div className="absolute top-3 -right-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                      style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 75% 50%, 100% 100%, 0 100%)' }} />

                                    <div className="absolute -bottom-3 left-0 w-6 h-3 -z-10 brightness-50"
                                      style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />

                                    <div className="absolute -bottom-3 right-0 w-6 h-3 -z-10 brightness-50"
                                      style={{ backgroundColor: currentRibbonColor, clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                                  </>
                                )}

                                {/* Main Banner */}
                                <div className="flex items-center gap-3 relative z-30">
                                  <div className={currentRibbonColor !== 'none' ? "relative px-8 md:px-14 py-3 rounded-sm border-b-[6px] border-r-4 border-black/30 shadow-xl flex flex-col sm:flex-row items-center gap-3 decoration-transparent" : `relative px-8 ${catOttIsActive ? 'py-1' : 'py-3'} flex flex-col sm:flex-row items-center gap-3 decoration-transparent hover:scale-[1.02] transition-transform`} style={currentRibbonColor !== 'none' ? { backgroundColor: currentRibbonColor, backgroundImage: cat.ribbonImage ? `url('${cat.ribbonImage}')` : undefined, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
                                    <a href={`/?category=${cat.id}&from=${categoryId || 'root'}`} className="absolute inset-0 z-0" aria-label={cat.name}></a>
                                    <div className="flex flex-row items-center gap-2 relative z-10 pointer-events-none">
                                      {/* Add PostIt Form Trigger for this Category */}
                                      {catOttIsActive && (
                                        <div className="pointer-events-auto flex items-center pr-1">
                                          <PostItForm 
                                            categories={categories}
                                            defaultCategoryId={cat.id}
                                            userGroupIds={(session?.user as any)?.userGroupIds}
                                            userRole={(session?.user as any)?.role}
                                            customTrigger={
                                              <div className="bg-gradient-to-br from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 shadow-md border border-yellow-300 p-1 sm:p-1.5 rounded-lg cursor-pointer flex items-center justify-center hover:scale-110 transition-transform duration-300 mt-0.5" title={`${cat.name} Kategorisine Post-it Ekle`}>
                                                <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-950" strokeWidth={3} />
                                              </div>
                                            }
                                          />
                                        </div>
                                      )}
                                      <h2 className={`${activeTitleSize} tracking-normal mb-0`}
                                        style={{
                                          color: activeTitleColor,
                                          textShadow: cat.ribbonTextColor === 'transparent' ? 'none' : (currentRibbonColor !== 'none' ? '0 1px 0 rgba(255,255,255,0.3), 0 2px 0 rgba(255,255,255,0.2), 0 3px 0 rgba(255,255,255,0.1), 0 4px 0 rgba(0,0,0,0.1), 0 5px 0 rgba(0,0,0,0.15), 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15)' : 'none'),
                                          fontFamily: activeTitleFont,
                                          fontWeight: 900
                                        }}>
                                        {cat.name}
                                      </h2>
                                      <div className="flex items-center gap-1.5 opacity-90 mt-1 pointer-events-auto cursor-default">
                                        {(subcatCount > 0) && (
                                          <span className="text-[11px] bg-blue-100/90 backdrop-blur-sm text-blue-800 font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm border border-blue-400">
                                            <ListTree className="w-3 h-3" /> {subcatCount}
                                          </span>
                                        )}
                                        <span className="text-[11px] bg-yellow-100/90 backdrop-blur-sm text-yellow-800 font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm border border-yellow-500">
                                          <StickyNote className="w-3 h-3" /> {postitCount}
                                        </span>
                                        <CategorySubscribeButton categoryId={cat.id} variant="badge" />
                                        <CategoryMessageButton categoryId={cat.id} categoryName={cat.name} />
                                        <CategoryShareButton categoryId={cat.id} />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            )}
                            
                            {catOttIsActive && ottSettings.separatorStyle !== 'none' && (
                              <div className="w-full flex justify-center mt-0 mb-1">
                                <div className="w-[95%] border-b-2" style={{ borderBottomStyle: ottSettings.separatorStyle as any, borderColor: ottSettings.separatorColor || '#cbd5e1' }} />
                              </div>
                            )}

                            <div
                              className={`relative flex overflow-hidden transition-all duration-300 ${catOttIsActive && ottSettings.topMenuLabelHasBorder ? 'shadow-[inset_0_0_20px_rgba(0,0,0,0.4),0_6px_12px_rgba(0,0,0,0.2)] rounded-sm' : (!catOttIsActive && !cat.noInnerBorder && !cat.isInnerTransparent ? 'shadow-[inset_0_0_20px_rgba(0,0,0,0.4),0_6px_12px_rgba(0,0,0,0.2)] rounded-sm' : '')} z-10 flex-1 w-full`}
                              style={catOttIsActive ? {
                                ...(ottSettings.topMenuLabelHasBorder ? { border: `4px solid ${ottSettings.separatorColor || '#ffffff'}` } : {}),
                                backgroundColor: ottSettings.topMenuLabelBgColor || 'transparent'
                              } : {
                                ...(!cat.noInnerBorder && !cat.isInnerTransparent ? { border: `12px solid ${cat.borderColor || '#8B5A2B'}` } : {}),
                                backgroundColor: cat.isInnerTransparent ? 'transparent' : (cat.innerBackgroundColor || (!cat.noInnerBorder ? '#E8DCC4' : 'transparent'))
                              }}
                            >
                              {!catOttIsActive && !cat.noInnerBorder && !cat.isInnerTransparent && (
                                <div className="absolute inset-0 opacity-40 mix-blend-multiply pointer-events-none" style={{ backgroundImage: 'url("/patterns/cork.png")', backgroundSize: '150px' }} />
                              )}
                              <div className="relative z-10 w-full p-2 h-full flex flex-col items-center">
                                {catOttIsActive ? (
                                  <OttSlider
                                    initialPostits={catPostits as any}
                                    canDelete={canDelete}
                                    currentUserId={(session?.user as any)?.id}
                                    separatorAds={separatorAds}
                                    postitAppearance={(() => {
                                      const raw = cat.postitAppearance;
                                      if (typeof raw === 'string') {
                                        try { return JSON.parse(raw); } catch(e){ return null; }
                                      }
                                      return raw ? JSON.parse(JSON.stringify(raw)) : null;
                                    })()}
                                    ottItemsPerRow={catOttItemsPerRow}
                                    ottCardRatio={catOttCardRatio}
                                    ottAutoScrollSpeed={catOttAutoScrollSpeed}
                                    ottCardStyle={catOttCardStyle}
                                    ottCardBgType={catOttCardBgType}
                                    ottCardBgColor={catOttCardBgColor}
                                    ottCardBgImage={catOttCardBgImage}
                                    ottModalBgType={catOttModalBgType}
                                    ottModalBgColor={catOttModalBgColor}
                                    ottModalBgColorAlpha={catOttModalBgColorAlpha}
                                    ottModalBgImage={catOttModalBgImage}
                                    ottModalTextColor={catOttModalTextColor}
                                  />
                                ) : (
                                  <PostItWall
                                    initialPostits={catPostits as any}
                                    canDelete={canDelete}
                                    currentUserId={(session?.user as any)?.id}
                                    separatorAds={separatorAds}
                                    postitAppearance={(() => {
                                      const raw = cat.postitAppearance;
                                      if (typeof raw === 'string') {
                                        try { return JSON.parse(raw); } catch(e){ return null; }
                                      }
                                      return raw ? JSON.parse(JSON.stringify(raw)) : null;
                                    })()}
                                    ottModalBgType={catOttModalBgType}
                                    ottModalBgColor={catOttModalBgColor}
                                    ottModalBgColorAlpha={catOttModalBgColorAlpha}
                                    ottModalBgImage={catOttModalBgImage}
                                    ottModalTextColor={catOttModalTextColor}
                                    ottCardRatio={catOttCardRatio}
                                  />
                                )}
                              </div>
                            </div>
                            
                            {/* Separator Ad */}
                            {separatorAds.length > 0 && ((index + 1) % ((separatorAds[index % separatorAds.length] as any).frequency || 1) === 0) && (
                              <div className="w-full flex justify-center pt-8 pb-4">
                                <a href={separatorAds[index % separatorAds.length].link} target="_blank" rel="noopener noreferrer" className="relative block w-full bg-white border border-gray-200 p-1 shadow-sm rounded-md transition-transform hover:scale-[1.01]">
                                  <span className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded shadow z-10">Sponsorlu</span>
                                  <img src={separatorAds[index % separatorAds.length].imageUrl} alt="Sponsor" className="w-full max-h-[120px] md:max-h-[180px] object-cover rounded" />
                                </a>
                              </div>
                            )}

                          </div>
                        )
                      })}
                    </div>
                  );
                } else {
                  const currentWallLimit = categoryId ? (selectedCategory?.postitLimit || 0) : (homeWall?.postitLimit || 0);
                  const limitedPostits = currentWallLimit > 0 ? postits.slice(0, currentWallLimit) : postits;

                  return (
                    <div className={`w-full mt-4 ${ottSettings.isActive ? 'flex flex-col gap-2' : 'space-y-12'}`}>
                      <div className={ottSettings.isActive ? "mb-2" : "mb-12"}>
                        {ottSettings.isActive ? (
                          ottSettings.showCategoryTitles && (
                            <>
                              <div className={`relative flex ${ottSettings.categoryTitleAlignment === 'left' ? 'justify-start md:ml-12 ml-4' : ottSettings.categoryTitleAlignment === 'right' ? 'justify-end md:mr-12 mr-4' : 'justify-center'} w-full ${appearance.ribbonColor === 'none' ? 'mt-3 mb-1' : 'mt-4 mb-2'} z-10 transition-transform hover:scale-105 duration-300`}>
                                <div className="relative inline-flex items-center justify-center group">
                                  {appearance.ribbonColor !== 'none' && (
                                    <>
                                      <div className="absolute top-3 -left-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 25% 50%)' }} />
                                      <div className="absolute top-3 -right-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 75% 50%, 100% 100%, 0 100%)' }} />
                                      <div className="absolute -bottom-3 left-0 w-6 h-3 -z-10 brightness-50"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                                      <div className="absolute -bottom-3 right-0 w-6 h-3 -z-10 brightness-50"
                                        style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                                    </>
                                  )}
                                  <div className="flex items-center gap-3 relative z-30">
                                    <div className={appearance.ribbonColor !== 'none' ? "relative px-8 md:px-14 py-3 rounded-sm border-b-[6px] border-r-4 border-black/30 shadow-xl flex flex-col sm:flex-row items-center gap-3 decoration-transparent bg-cover bg-center" : `relative px-8 py-1 flex flex-col sm:flex-row items-center gap-3 decoration-transparent hover:scale-[1.02] transition-transform`} style={appearance.ribbonColor !== 'none' ? { backgroundColor: appearance.ribbonColor, backgroundImage: appearance.ribbonImage ? `url('${appearance.ribbonImage}')` : 'none' } : {}}>
                                      <div className="flex flex-row items-center gap-2 relative z-10 pointer-events-none">
                                        <div className="pointer-events-auto flex items-center pr-1">
                                          <PostItForm 
                                            categories={categories}
                                            defaultCategoryId={selectedCategory?.id || homeWall?.id!}
                                            userGroupIds={(session?.user as any)?.userGroupIds}
                                            userRole={(session?.user as any)?.role}
                                            customTrigger={
                                              <div className="bg-gradient-to-br from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 shadow-md border border-yellow-300 p-1 sm:p-1.5 rounded-lg cursor-pointer flex items-center justify-center hover:scale-110 transition-transform duration-300 mt-0.5" title="Kategoriye Post-it Ekle">
                                                <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-950" strokeWidth={3} />
                                              </div>
                                            }
                                          />
                                        </div>
                                        <h2 className={`${ottSettings.categoryTitleSize === 'xl' ? 'text-xl md:text-2xl' : ottSettings.categoryTitleSize === '2xl' ? 'text-2xl md:text-3xl' : ottSettings.categoryTitleSize === '3xl' ? 'text-3xl md:text-4xl' : ottSettings.categoryTitleSize === '4xl' ? 'text-4xl md:text-5xl' : ottSettings.categoryTitleSize === '5xl' ? 'text-5xl md:text-6xl' : 'text-3xl md:text-5xl'} tracking-normal mb-0`}
                                          style={{
                                            color: ottSettings.categoryTitleColor || (appearance.ribbonTextColor === 'transparent' ? 'transparent' : (appearance.ribbonTextColor || (appearance.ribbonColor !== 'none' ? '#ffffff' : '#1f2937'))),
                                            textShadow: appearance.ribbonTextColor === 'transparent' ? 'none' : (appearance.ribbonColor !== 'none' ? '0 1px 0 rgba(255,255,255,0.3), 0 2px 0 rgba(255,255,255,0.2), 0 3px 0 rgba(255,255,255,0.1), 0 4px 0 rgba(0,0,0,0.1), 0 5px 0 rgba(0,0,0,0.15), 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15)' : 'none'),
                                            fontFamily: ottSettings.categoryTitleFont === 'handwriting' ? "'Caveat', cursive" : ottSettings.categoryTitleFont === 'london' ? "'London Presley', sans-serif" : ottSettings.categoryTitleFont === 'puerto' ? "'Puerto', sans-serif" : ottSettings.categoryTitleFont === 'retosta' ? "'Retosta', sans-serif" : ottSettings.categoryTitleFont === 'Dancing Script, cursive' ? "'Dancing Script', cursive" : "'Nunito', 'Segoe UI', system-ui, sans-serif",
                                            fontWeight: 900
                                          }}>
                                          {appearance.customRibbonText || selectedCategory?.name || 'Ana Duvar'}
                                        </h2>
                                        <div className="flex items-center gap-1.5 opacity-90 mt-1 pointer-events-auto cursor-default">
                                          <span className="text-[11px] bg-yellow-100/90 backdrop-blur-sm text-yellow-800 font-bold px-1.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm border border-yellow-500">
                                            <StickyNote className="w-3 h-3" /> {limitedPostits.length}
                                          </span>
                                          {(selectedCategory || homeWall) && (
                                            <CategorySubscribeButton categoryId={selectedCategory?.id || homeWall?.id!} variant="badge" />
                                          )}
                                          {(selectedCategory || homeWall) && (
                                            <CategoryMessageButton categoryId={selectedCategory?.id || homeWall?.id!} categoryName={selectedCategory?.name || homeWall?.name || 'Ana Duvar'} />
                                          )}
                                          {(selectedCategory || homeWall) && (
                                            <CategoryShareButton categoryId={selectedCategory?.id || homeWall?.id!} />
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              {ottSettings.separatorStyle !== 'none' && (
                                <div className="w-full flex justify-center mt-0 mb-1">
                                  <div className="w-[95%] border-b-2" style={{ borderBottomStyle: ottSettings.separatorStyle as any, borderColor: ottSettings.separatorColor || '#cbd5e1' }} />
                                </div>
                              )}
                            </>
                          )
                        ) : (
                          !appearance.hideWallTitle && (
                            <div className="relative flex justify-center w-full mt-6 mb-8 z-10 transition-transform hover:scale-105 duration-300">
                              <div className="relative inline-flex items-center justify-center group">
                                {!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' && (
                                  <>
                                    <div className="absolute top-3 -left-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                      style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%, 25% 50%)' }} />
                                    <div className="absolute top-3 -right-10 w-16 h-full -z-20 drop-shadow-md brightness-75"
                                      style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 75% 50%, 100% 100%, 0 100%)' }} />
                                    <div className="absolute -bottom-3 left-0 w-6 h-3 -z-10 brightness-50"
                                      style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                                    <div className="absolute -bottom-3 right-0 w-6 h-3 -z-10 brightness-50"
                                      style={{ backgroundColor: appearance.ribbonColor, clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                                  </>
                                )}
                                <div className={!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? "relative px-8 md:px-14 py-3 rounded-sm border-b-[6px] border-r-4 border-black/30 shadow-xl flex flex-col sm:flex-row items-center gap-3 decoration-transparent bg-cover bg-center" : "relative px-8 py-3 flex flex-col sm:flex-row items-center gap-3 decoration-transparent"} style={!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? { backgroundColor: appearance.ribbonColor, backgroundImage: appearance.ribbonImage ? `url(${appearance.ribbonImage})` : 'none' } : {}}>
                                  <h2 className={`relative z-10 text-3xl md:text-5xl tracking-normal mb-0`}
                                    style={{
                                      color: appearance.ribbonTextColor || (!appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? '#ffffff' : '#1f2937'),
                                      textShadow: !appearance.hideWallRibbon && appearance.ribbonColor !== 'none' ? '0 1px 0 rgba(255,255,255,0.3), 0 2px 0 rgba(255,255,255,0.2), 0 3px 0 rgba(255,255,255,0.1), 0 4px 0 rgba(0,0,0,0.1), 0 5px 0 rgba(0,0,0,0.15), 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15)' : 'none',
                                      fontFamily: appearance.ribbonTextFont === 'cursive' ? "'Patrick Hand', cursive" : appearance.ribbonTextFont === 'serif' ? 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif' : appearance.ribbonTextFont === 'monospace' ? 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace' : appearance.ribbonTextFont === 'system-ui' ? 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif' : "'Nunito', 'Segoe UI', system-ui, sans-serif",
                                      fontWeight: 900
                                    }}>
                                    {appearance.customRibbonText || selectedCategory?.name || 'Ana Duvar'}
                                  </h2>
                                </div>
                              </div>
                            </div>
                          )
                        )}
                        <div
                          className={`relative flex overflow-hidden transition-all duration-300 ${!boardAppearance.noInnerBorder && !boardAppearance.isInnerTransparent ? 'shadow-[inset_0_0_20px_rgba(0,0,0,0.4),0_6px_12px_rgba(0,0,0,0.2)] rounded-sm' : ''} z-10 flex-1 w-full`}
                          style={{
                            ...(!boardAppearance.noInnerBorder && !boardAppearance.isInnerTransparent ? { border: `12px solid ${boardAppearance.borderColor || '#8B5A2B'}` } : {}),
                            backgroundColor: boardAppearance.isInnerTransparent ? 'transparent' : (boardAppearance.innerBackgroundColor || (!boardAppearance.noInnerBorder ? '#E8DCC4' : 'transparent'))
                          }}
                        >
                          {!boardAppearance.noInnerBorder && !boardAppearance.isInnerTransparent && (
                            <div className="absolute inset-0 opacity-40 mix-blend-multiply pointer-events-none" style={{ backgroundImage: 'url("/patterns/cork.png")', backgroundSize: '150px' }} />
                          )}
                          <div className="relative z-10 w-full p-2 h-full flex flex-col items-center">
                            {ottSettings.isActive ? (
                              <OttSlider
                                initialPostits={limitedPostits as any}
                                canDelete={canDelete}
                                currentUserId={(session?.user as any)?.id}
                                separatorAds={separatorAds}
                                postitAppearance={appearance.postitAppearance}
                                ottItemsPerRow={ottSettings.itemsPerRow}
                                ottCardRatio={ottSettings.cardRatio}
                                ottAutoScrollSpeed={ottSettings.autoScrollSpeed}
                                ottCardStyle={ottSettings.cardStyle}
                                ottCardBgType={ottSettings.cardBgType}
                                ottCardBgColor={ottSettings.cardBgColor}
                                ottCardBgImage={ottSettings.cardBgImage}
                                ottModalBgType={ottSettings.modalBgType}
                                ottModalBgColor={ottSettings.modalBgColor}
                                ottModalBgColorAlpha={ottSettings.modalBgColorAlpha}
                                ottModalBgImage={ottSettings.modalBgImage}
                                ottModalTextColor={ottSettings.modalTextColor}
                              />
                            ) : (
                              <PostItWall
                                initialPostits={limitedPostits as any}
                                canDelete={canDelete}
                                currentUserId={(session?.user as any)?.id}
                                separatorAds={separatorAds}
                                postitAppearance={appearance.postitAppearance}
                                ottModalBgType={ottSettings.modalBgType}
                                ottModalBgColor={ottSettings.modalBgColor}
                                ottModalBgColorAlpha={ottSettings.modalBgColorAlpha}
                                ottModalBgImage={ottSettings.modalBgImage}
                                ottModalTextColor={ottSettings.modalTextColor}
                                ottCardRatio={ottSettings.cardRatio}
                              />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                }
              })()}

              {/* Bottom Ads Wrapper */}
              {bottomAds.length > 0 && (
                <div className="w-full flex justify-center py-4 mt-8 z-20">
                  <div className="w-full flex flex-col gap-4">
                    {bottomAds.map((ad: any) => (
                      <a key={ad.id} href={ad.link} target="_blank" rel="noopener noreferrer" className="relative block w-full bg-white border border-gray-200 p-1 shadow-sm rounded-md transition-transform hover:scale-[1.01]">
                        <span className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-0.5 rounded shadow z-10">Sponsorlu</span>
                        <img src={ad.imageUrl} alt={ad.title} className="w-full max-h-[120px] md:max-h-[180px] object-cover rounded" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </main>

          {/* Right Sidebar Ads */}
          {rightAds.length > 0 && (
            <aside className="hidden lg:flex flex-col w-[160px] xl:w-[200px] shrink-0">
              <div className="sticky top-24 flex flex-col gap-4">
                {rightAds.map((ad: any) => (
                  <a key={ad.id} href={ad.link} target="_blank" rel="noopener noreferrer" className="block relative bg-white border p-1 border-gray-200 shadow-sm rounded-md transition-transform hover:scale-105 group">
                    <span className="absolute -top-2 -left-2 bg-indigo-600 text-white text-[9px] px-1.5 py-0.5 rounded shadow z-10">Sponsorlu</span>
                    <img src={ad.imageUrl} alt={ad.title} className="w-full h-auto rounded" />
                  </a>
                ))}
              </div>
            </aside>
          )}

          {/* Side Calendar Section */}
          {siteSettings.calendarShow !== false && (siteSettings.calendarPosition === 'left' || siteSettings.calendarPosition === 'right' || !siteSettings.calendarPosition) && (
            <aside className={`${siteSettings.calendarSize === 'large' ? 'lg:w-40' : siteSettings.calendarSize === 'small' ? 'lg:w-24' : 'lg:w-32'} flex flex-col items-center ${siteSettings.calendarPosition === 'left' ? 'lg:items-end' : 'lg:items-start'}`}>
              <div className="sticky top-8">
                {clickableCalendarLeaf}
              </div>
            </aside>
          )}
        </div>
      </div>
    </div>
  )
}
