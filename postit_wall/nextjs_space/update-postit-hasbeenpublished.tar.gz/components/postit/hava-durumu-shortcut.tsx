'use client'

import { CloudSun } from 'lucide-react'

export function HavaDurumuShortcut({ mobile }: { mobile?: boolean }) {
  const scrollToWeather = () => {
    // Tüm kategori başlıklarını bul
    const headings = Array.from(document.querySelectorAll('h2'));
    const weatherHeading = headings.find(h => h.textContent?.toLowerCase().includes('hava durumu'));
    
    if (weatherHeading) {
      // Başlığın içindeki veya etrafındaki kategori id'sine sahip olan ana div'i bul
      const section = weatherHeading.closest('div[id^="category-"]');
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
        
        // Dikkat çekmek için kısa süreli bir parlatma efekti
        section.classList.add('animate-pulse');
        setTimeout(() => section.classList.remove('animate-pulse'), 1500);
        return;
      }
    }
  }

  if (mobile) {
    return (
      <button 
        onClick={scrollToWeather} 
        className="flex items-center gap-1.5 ml-3 transition-transform duration-300 hover:scale-[1.03] opacity-90 hover:opacity-100 cursor-pointer border-none bg-transparent"
      >
        <div className="bg-white/20 p-1 rounded-sm backdrop-blur-sm shadow-sm flex items-center justify-center">
          <CloudSun className="w-5 h-5 text-white" />
        </div>
        <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-white">Hava Durumu</span>
      </button>
    )
  }

  return (
    <button 
      onClick={scrollToWeather} 
      className="block mt-2 transition-transform duration-300 hover:scale-[1.03] hover:drop-shadow-sm opacity-90 hover:opacity-100 cursor-pointer border-none bg-transparent p-0" 
      title="Hava Durumu Duvarına Git"
    >
      <div className="bg-white/60 p-1.5 rounded-sm backdrop-blur-sm shadow-sm flex items-center justify-center h-9 w-auto px-3 border border-white/40">
        <CloudSun className="w-5 h-5 text-indigo-900 mr-2" />
        <span className="text-sm font-bold text-indigo-900 hover:text-indigo-700">Hava Durumu</span>
      </div>
    </button>
  )
}
