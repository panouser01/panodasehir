'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useSearchParams } from 'next/navigation'
import { toast } from 'react-hot-toast'
import { MessageCircle, Send, X } from 'lucide-react'

export function AdminMessageFab() {
  const { data: session } = useSession()
  const searchParams = useSearchParams()
  const [isOpen, setIsOpen] = useState(false)
  const [message, setMessage] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const currentCategoryId = searchParams?.get('category') || 'root' // Defaults to home wall if undefined, wait no, categoryId must be valid UUID or null. 
  // Let's use the fact that if category is not in URL, we might need a default root category id.
  // Actually, we can fetch the root category if it's not provided or just use null if the backend allows it.
  // The postit generation requires a valid categoryId. If the user is on the main wall, searchParams.get('category') is null.
  // We can fetch the primary wall ID dynamically, or better yet, since the modal is only useful if there's a valid ID, let's just make an API call to get it or pass it. 
  // For simplicity, let's allow the user to select the wall they are messaging, or default to the current wall.

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    setIsSubmitting(true)
    
    // Fallback: fetch root category if no category selected
    let effectiveCategoryId = currentCategoryId
    if (effectiveCategoryId === 'root' || !effectiveCategoryId) {
        const rootRes = await fetch('/api/categories?includeRoot=true')
        const rootData = await rootRes.json()
        const rootCat = rootData?.categories?.find((c: any) => c.parentId === null && c.name === 'Ana Duvar') || rootData?.categories?.[0]
        if (rootCat) {
            effectiveCategoryId = rootCat.id
        } else {
            toast.error("Hedef duvar bulunamadı.")
            setIsSubmitting(false)
            return
        }
    }

    try {
      const res = await fetch('/api/postits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: message,
          categoryId: effectiveCategoryId,
          isDirectMessage: true,
          color: 'YELLOW',
          font: 'HANDWRITING',
          pushpin: 'BLUE',
          expiresInDays: '30'
        })
      })

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}))
        throw new Error(errorData.error || 'Mesaj gönderilemedi')
      }

      toast.success('Mesajınız duvar sahibine başarıyla iletildi!')
      setIsOpen(false)
      setMessage('')
    } catch (error: any) {
      toast.error(error.message || 'Mesaj gönderilirken hata oluştu')
    } finally {
      setIsSubmitting(false)
    }
  }

  // Only show if user is logged in
  if (!session) return null

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-28 md:bottom-6 right-6 md:right-auto md:left-6 z-[90] flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-indigo-600 text-white rounded-full shadow-2xl hover:bg-indigo-700 transition-all hover:scale-105 active:scale-95"
        title="Duvar Sahibine Mesaj Gönder"
      >
        <MessageCircle size={28} />
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 animate-in fade-in" onClick={() => setIsOpen(false)}>
          <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-sm p-6" onClick={e => e.stopPropagation()}>
            <button onClick={() => setIsOpen(false)} className="absolute top-3 right-3 text-gray-500 hover:text-gray-800">
              <X size={24} />
            </button>
            <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
              <MessageCircle className="text-indigo-600" />
              Duvar Sahibine Mesaj
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Bu mesaj sadece duvar yöneticileri ve site yöneticileri tarafından okunabilir, panoda yayınlanmaz.
            </p>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Mesajınızı buraya yazın..."
                className="w-full h-32 p-3 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                required
                maxLength={1000}
              />
              <div className="flex justify-end p-1">
                <span className={`text-xs ${message.length > 950 ? 'text-orange-500 font-bold' : 'text-gray-400'}`}>
                  {message.length}/1000
                </span>
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting || !message.trim()}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Send size={18} />
                  {isSubmitting ? 'Gönderiliyor...' : 'Gönder'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
