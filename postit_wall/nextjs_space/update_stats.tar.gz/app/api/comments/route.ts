import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { moderateContent } from '@/lib/moderation'
import { sendTelegramMessage } from '@/lib/telegram'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Giriş yapmalısınız' }, { status: 401 })
    }

    const { content, postItId } = await request.json()
    if (!content || !postItId) {
      return NextResponse.json({ error: 'İçerik ve postItId gereklidir' }, { status: 400 })
    }

    const moderation = await moderateContent(content)
    if (!moderation.isApproved) {
      return NextResponse.json({ error: 'Uygunsuz içerik engellendi', reason: moderation.reason }, { status: 400 })
    }

    const comment = await prisma.postItComment.create({
      data: {
        content,
        postItId,
        userId: (session.user as any).id
      },
      include: {
        user: { select: { id: true, name: true, nickname: true, image: true } }
      }
    })

    // Telegram Bildirimi: Postit sahibine mesaj gönder
    try {
      const postOwner = await prisma.postIt.findUnique({
        where: { id: postItId },
        include: { user: { select: { id: true, telegramChatId: true } } }
      });

      const currentUserId = (session.user as any).id;
      if (postOwner?.user?.telegramChatId && postOwner.user.id !== currentUserId) {
         const msg = `💬 <b>Postitinize yeni bir yorum geldi!</b>\n\n` +
                     `<b>Postitiniz:</b> <i>${postOwner.content.substring(0, 30)}...</i>\n` +
                     `<b>Yazan:</b> ${comment.user.name || 'Bir kullanıcı'}\n` +
                     `<b>Yorum:</b> ${comment.content}\n`;
         await sendTelegramMessage(postOwner.user.telegramChatId, msg);
      }
    } catch (err) {
      console.error("Yorum telegram bildirim hatası:", err);
    }

    return NextResponse.json({ comment }, { status: 201 })
  } catch (error) {
    console.error('Yorum eklenirken hata:', error)
    return NextResponse.json({ error: 'Yorum eklenemedi' }, { status: 500 })
  }
}
