export const sendTelegramMessage = async (
  chatId: string,
  text: string,
  replyMarkup?: any
) => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.warn("TELEGRAM_BOT_TOKEN tanımlı değil!");
    return null;
  }

  const TELEGRAM_API_URL = `https://api.telegram.org/bot${token}/sendMessage`;

  try {
    const res = await fetch(TELEGRAM_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: "HTML",
        reply_markup: replyMarkup,
      }),
    });

    const data = await res.json();
    if (!res.ok) {
      console.error("Telegram Error:", data);
    }
    return data;
  } catch (error) {
    console.error("Telegram gönderme hatası:", error);
    return null;
  }
};

export const answerCallbackQuery = async (
  callbackQueryId: string,
  text?: string,
  showAlert: boolean = false
) => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text: text,
        show_alert: showAlert,
      }),
    });
    return await res.json();
  } catch (error) {
    console.error("Telegram answerCallbackQuery Error:", error);
    return null;
  }
};

export const notifySubscribers = async (categoryId: string, categoryName: string, postitContent: string, authorName: string, authorId?: string) => {
  try {
    // Lazy load prisma to avoid circular dependencies if any
    const { prisma } = await import('@/lib/db');
    
    // Find all users subscribed to this category who have a telegram chat ID connected
    const query: any = {
      telegramChatId: { not: null },
      wallSubscriptions: { some: { categoryId: categoryId } }
    };
    if (authorId) {
      query.id = { not: authorId };
    }

    const subscribers = await prisma.user.findMany({
      where: query,
      select: { telegramChatId: true }
    });
    
    if (subscribers.length === 0) return;
    
    // HTML Escape function for Telegram
    const escapeHtml = (text: string) => {
      return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    };

    const safeContent = escapeHtml(postitContent);
    const safeAuthor = escapeHtml(authorName);
    const safeCategory = escapeHtml(categoryName);
    
    const messageText = `🔔 <b>Yeni Bildirim!</b>\n\nAbone olduğunuz <b>${safeCategory}</b> duvarına ${safeAuthor} tarafından yeni bir post-it eklendi:\n\n<i>"${safeContent.length > 200 ? safeContent.substring(0, 200) + '...' : safeContent}"</i>\n\n<a href="https://panodasehir.com/?category=${categoryId}">Hemen İncele</a>`;
    
    const inlineKeyboard = {
      inline_keyboard: [
        [
          { text: "🔗 Duvara Git", url: `https://panodasehir.com/?category=${categoryId}` }
        ]
      ]
    };
    
    const promises = [];
    // Send message to each subscriber
    for (const sub of subscribers) {
      if (sub.telegramChatId) {
        promises.push(sendTelegramMessage(sub.telegramChatId, messageText, inlineKeyboard).catch(console.error));
      }
    }
    
    // Await all promises so Next.js doesn't abort the fetch calls when request ends
    await Promise.all(promises);
  } catch (error) {
    console.error("Error notifying subscribers via Telegram:", error);
  }
};
