'use client'

import React, { useState } from 'react'
import { Eye, Heart, MessageSquare } from 'lucide-react'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { X } from 'lucide-react'

interface PostitMasonryGridProps {
  postits: any[];
  postitAppearance?: any;
  itemsPerRow?: number;
  cardRatio?: string;
}

export function PostitMasonryGrid({ postits, postitAppearance, itemsPerRow: propItemsPerRow, cardRatio: propCardRatio }: PostitMasonryGridProps) {
  const [previewImage, setPreviewImage] = useState<string | null>(null)

  const itemsPerRow = propItemsPerRow || postitAppearance?.editorItemsPerRow || 3
  const imageRatio = propCardRatio || postitAppearance?.editorImageRatio || '16/9'
  const cardBgColor = postitAppearance?.editorCardBgColor || '#ffffff'
  const titleColor = postitAppearance?.editorTitleColor || '#111827'
  const titleFont = postitAppearance?.editorTitleFont || 'sans-serif'
  const titleSize = postitAppearance?.editorTitleSize || 'xl'
  const cardStyle = postitAppearance?.editorCardStyle || 'modern'

  const getGridCols = () => {
    switch(itemsPerRow) {
      case 1: return 'grid-cols-1'
      case 2: return 'grid-cols-1 md:grid-cols-2'
      case 4: return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-4'
      case 5: return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5'
      case 3:
      default: return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
    }
  }

  


  const getCardStyleClass = () => {
    switch (cardStyle) {
      case 'flat': return 'border-none shadow-none rounded-none'
      case 'bordered': return 'border-2 border-slate-900 shadow-[4px_4px_0_0_rgba(0,0,0,1)] rounded-xl'
      case 'glass': return 'bg-white/40 backdrop-blur-md border border-white/40 shadow-xl rounded-2xl'
      case 'modern':
      default: return 'border-gray-100 shadow-lg rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-1'
    }
  }

  const getFontFamily = () => {
    switch (titleFont) {
      case 'serif': return '"Playfair Display", ui-serif, Georgia, serif'
      case 'handwriting': return '"Caveat", cursive'
      case 'london': return '"London Presley", sans-serif'
      case 'puerto': return '"Puerto", sans-serif'
      case 'retosta': return '"Retosta", sans-serif'
      case 'sans-serif':
      default: return 'inherit'
    }
  }

  return (
    <div className="w-full flex-col flex items-center mb-8 px-4 sm:px-0">
      {postits.length === 0 ? (
        <div className="w-full text-center py-20 bg-white/50 backdrop-blur border border-dashed border-slate-300 rounded-3xl max-w-4xl opacity-80 mt-4">
          <h3 className="text-xl font-bold text-slate-600">Henüz Not Yok</h3>
        </div>
      ) : (
        <div className={`grid ${getGridCols()} gap-6 lg:gap-8 w-full max-w-[1400px]`}>
          {postits.map((postit) => (
            <div 
              key={postit.id}
              className={`flex flex-col transition-all duration-300 ${getCardStyleClass()} relative`}
              style={{ backgroundColor: cardStyle !== 'glass' ? cardBgColor : undefined }}
            >
              {(postit.imageUrl || (postit.imageUrls && postit.imageUrls.length > 0)) ? (
                <div className="w-full overflow-hidden relative bg-slate-100 cursor-pointer" style={{ aspectRatio: imageRatio === "auto" ? "auto" : imageRatio }}
                  onClick={() => setPreviewImage(postit.imageUrl || postit.imageUrls[0])}
                >
                  <img src={postit.imageUrl || postit.imageUrls[0]} alt="Postit Görseli" className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
                  {postit.user?.name && (
                    <div className="absolute bottom-3 left-3 bg-white/10 backdrop-blur-md text-xs font-bold text-slate-800 px-3 py-1.5 rounded-full shadow-sm truncate max-w-[80%] flex items-center gap-2">
                      {(postit.user?.image && postit.user.showAvatarOnPostit !== false) && (
                         <img src={postit.user.image} alt={postit.user.name} className="w-5 h-5 rounded-full border border-slate-200" />
                      )}
                      <span className="truncate">{postit.user.nickname || postit.user.name || 'Anonim'}</span>
                    </div>
                  )}
                </div>
              ) : (postit.user?.name && (
                 <div className="px-6 pt-4">
                    <div className="bg-slate-100/50 backdrop-blur-md text-xs font-bold text-slate-800 px-3 py-1.5 rounded-full shadow-sm inline-flex items-center gap-2">
                      {(postit.user?.image && postit.user.showAvatarOnPostit !== false) && (
                         <img src={postit.user.image} alt={postit.user.name} className="w-5 h-5 rounded-full border border-slate-200" />
                      )}
                      <span className="truncate">{postit.user.nickname || postit.user.name || 'Anonim'}</span>
                    </div>
                 </div>
              ))}
              <div className="p-6 flex flex-col flex-1 justify-between">
                <div>
                  {postit.category?.name && (
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">{postit.category.name}</div>
                  )}
                  <div 
                    className="font-bold leading-normal mb-3 whitespace-pre-wrap break-words prose prose-sm max-w-none text-left"
                    style={{ 
                      color: titleColor,
                      fontFamily: getFontFamily(),
                      fontSize: `var(--text-${titleSize}, 1.25rem)`,
                    }}
                    dangerouslySetInnerHTML={{ __html: postit.content }}
                  />
                </div>

                <div className="flex flex-col gap-3 pt-4 border-t border-slate-100 mt-auto">
                  <div className="flex items-center justify-between text-slate-600 px-1">
                    <div className="flex items-center gap-1.5 mt-1" title="Görüntüleme">
                      <Eye className="w-4 h-4 md:w-5 md:h-5" />
                      <span className="font-bold text-sm">{postit.views || 0}</span>
                    </div>
                    <div className="flex items-center gap-1.5" title="Beğeniler">
                      <Heart className="w-4 h-4 md:w-5 md:h-5 text-pink-500" />
                      <span className="font-bold text-sm">{postit.likesCount || 0}</span>
                    </div>
                    <div className="flex items-center gap-1.5" title="Yorumlar">
                      <MessageSquare className="w-4 h-4 md:w-5 md:h-5 text-indigo-500" />
                      <span className="font-bold text-sm">{postit.comments?.length || 0}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-end pt-2">
                    <div className="text-[11px] font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full shrink-0">
                      {new Date(postit.createdAt).toLocaleDateString('tr-TR')}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      <Dialog open={!!previewImage} onOpenChange={(open) => !open && setPreviewImage(null)}>
        <DialogContent className="max-w-[95vw] md:max-w-5xl p-0 bg-transparent border-none shadow-none flex justify-center items-center [&>button]:hidden [&>div]:border-none z-[99999]">
          {previewImage && (
            <div className="relative w-full h-full flex justify-center items-center" onClick={() => setPreviewImage(null)}>
              <button 
                onClick={() => setPreviewImage(null)}
                className="absolute top-2 right-2 md:-right-12 md:-top-12 p-2 bg-black/60 hover:bg-black/90 text-white rounded-full transition-colors z-50"
              >
                <X className="w-6 h-6" />
              </button>
              <img 
                src={previewImage} 
                className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl cursor-default"
                alt="Büyük Görsel"
                onClick={(e) => e.stopPropagation()} 
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
